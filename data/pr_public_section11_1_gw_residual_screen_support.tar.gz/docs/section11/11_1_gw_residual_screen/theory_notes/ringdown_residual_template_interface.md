# Ringdown Residual Template Interface

## Status

This note defines the first observable-template interface for the Projection Relativity finite-core restoration model.  The template is intended for use only after a full Kerr subtraction has been performed.

The old sideband-first language is not used here.  The ringdown residual is modeled as a finite-core restoration envelope rather than a new exterior quasinormal-mode ladder.

## Observable residual

Let

\[
r(t)=h_{\rm obs}(t)-h_{\rm Kerr}^{\rm full}(t),
\]

where \(h_{\rm Kerr}^{\rm full}\) includes the best available linear Kerr modes, overtones, subdominant angular modes, nonlinear Kerr corrections, merger-ringdown transition terms, and detector/systematic modeling.

The first PR residual model is

\[
\boxed{
r_X(t)
=
A_X e^{i\phi_X}
K_X\!\left(\frac{t-t_0}{\tau_X}\right)
+n(t).
}
\]

The free nuisance quantities in the first test are

\[
A_X,
\qquad
\phi_X,
\qquad
t_0,
\qquad
\tau_X.
\]

The shape of \(K_X\) is not free.

## Common-scale kernel

The common-scale closure sets

\[
\mathcal C_X^{\rm eff}=c_0 I
\]

on the parity-even finite-core dilation subspace.  Thus

\[
\Gamma_n=\frac{\mu_n^2}{c_0},
\qquad
\mu_n^2=\lambda_n-\lambda_0.
\]

The leading even channel \(n=2\) defines

\[
\Gamma_2^{\rm phys}=\frac{1}{\tau_X}.
\]

Therefore the scaled time is

\[
\boxed{
u=\frac{t-t_0}{\tau_X}.}
\]

To avoid confusion with frequency, the code uses the variable name `u` for this dimensionless scaled time.

## Locked kernel

The first-test kernel is

\[
\boxed{
K_X(u)
=
0.8340262441e^{-u}
+
0.1613211871e^{-2.2804425096u}
+
0.0045930762e^{-3.7432951884u}
+\cdots .
}
\]

For the three-mode normalized implementation used by the tester, the weights are renormalized by the captured three-mode weight \(0.9999405074\), giving

\[
K_X^{(2,4,6)}(0)=1.
\]

The first two modes capture approximately \(99.5347\%\) of the dilation source, and the first three modes capture approximately \(99.9941\%\).

## Software interface

The code module is:

```text
scripts/pr_ringdown_restoration_template_v10.py
```

The principal functions are:

```python
restoration_kernel(u, mode_set="three")
residual_template(t, amplitude, t0, tau_x, phi, mode_set="three")
envelope_template(t, amplitude, t0, tau_x, mode_set="three")
template_matrix(t, tau_grid, t0_grid, mode_set="three")
shape_times(mode_set="three")
```

The regression tester is:

```text
scripts/ringdown_residual_template_interface_tester_v10.py
```

It verifies:

- causal behavior, \(K_X(u<0)=0\);
- normalization, \(K_X(0)=1\);
- monotone decay over the tested range;
- locked mode weights and rate ratios;
- two-mode and three-mode captured source weights;
- residual-template onset phase and amplitude;
- template-matrix dimensions;
- shape times for \(K_X=0.5,e^{-1},0.1,0.01\).

Current result:

```text
26/26 checks passed
```

## Output files

The tester writes:

```text
results/pr_ringdown_restoration/ringdown_residual_template_interface_tester_v10_results.csv
results/pr_ringdown_restoration/ringdown_residual_template_interface_v10_modes.csv
results/pr_ringdown_restoration/ringdown_residual_template_interface_v10_kernel.csv
results/pr_ringdown_restoration/ringdown_residual_template_interface_v10_example_physical_template.csv
results/pr_ringdown_restoration/ringdown_residual_template_interface_v10_shape_times.csv
plots/pr_ringdown_restoration/ringdown_residual_template_interface_v10_kernel.png
plots/pr_ringdown_restoration/ringdown_residual_template_interface_v10_kernel.pdf
plots/pr_ringdown_restoration/ringdown_residual_template_interface_v10_example.png
plots/pr_ringdown_restoration/ringdown_residual_template_interface_v10_example.pdf
```

## Interpretation

This interface creates the first data-facing PR ringdown restoration template:

\[
\boxed{
\text{full Kerr subtraction}
\rightarrow
\text{finite-core restoration envelope test}.
}
\]

It is not a sideband search, not a hard-wall echo model, and not a replacement for Kerr.  It is a residual-envelope test for a stackable finite-core restoration process.
