# Ringdown Common-Scale Restoration Kernel

This note locks the first observational version of the Projection Relativity
finite-core restoration kernel.

## Decision

For the first gravitational-wave residual-stack test, the continuum/friction
operator is taken to be common-scale on the parity-even finite-core dilation
subspace,

\[
\mathcal C_X^{\rm eff}=c_0 I .
\]

This avoids introducing an unresolved projection-bath model before the bath
sector is explicitly derived. The physical time scale remains free, while the
shape of the restoration envelope is fixed by the radial branch and the
finite-core dilation source.

## Restoration operator

The radial branch is

\[
O_X
=
-\frac{d^2}{dw^2}
+
1+w^2+\frac34w^4 .
\]

The finite-core dilation source is

\[
\mathcal D_X
=
-2\frac{d^2}{dw^2}
-
2w^2
-
3w^4 .
\]

The Hessian on the radial branch is

\[
\mathcal H_X=O_X-\lambda_0.
\]

With the common-scale continuum closure,

\[
\hat{\Gamma}_X
=
(\mathcal C_X^{\rm eff})^{-1}\mathcal H_X
=
\frac{1}{c_0}(O_X-\lambda_0).
\]

Therefore

\[
\Gamma_n=\frac{\mu_n^2}{c_0},
\qquad
\mu_n^2=\lambda_n-\lambda_0 .
\]

## Leading symmetric dilation channel

Since the finite-core compression source is parity-even,

\[
S_{2k+1}=\langle u_{2k+1}|\mathcal D_X|u_0\rangle=0.
\]

The leading directly coupled restoration mode is therefore \(n=2\), not \(n=1\).

Define

\[
\Gamma_2^{\rm phys}
=
\frac{\mu_2^2}{c_0}
=
\frac{1}{\tau_X}.
\]

The scaled time variable is

\[
u=\frac{t-t_0}{\tau_X}.
\]

The unknown absolute continuum/friction scale is absorbed into \(\tau_X\).

## Locked first-test kernel

The normalized finite-core restoration kernel is

\[
K_X(u)
=
0.8340262441e^{-u}
+
0.1613211871e^{-2.2804425096u}
+
0.0045930762e^{-3.7432951884u}
+
5.9001\times10^{-5}e^{-5.3494810906u}
+\cdots .
\]

The two-mode truncated kernel is

\[
K_X^{(2,4)}(u)
=
0.8340262441e^{-u}
+
0.1613211871e^{-2.2804425096u}.
\]

The three-mode truncated kernel is

\[
K_X^{(2,4,6)}(u)
=
0.8340262441e^{-u}
+
0.1613211871e^{-2.2804425096u}
+
0.0045930762e^{-3.7432951884u}.
\]

The \(n=2\) and \(n=4\) channels carry \(99.5347\%\) of the dilation-source
weight. Including \(n=6\) captures \(99.9941\%\).

## Observable residual model

After full nonlinear Kerr subtraction,

\[
r(t)=h_{\rm obs}(t)-h_{\rm Kerr}^{\rm full}(t),
\]

the first PR residual template is

\[
r_X(t)
=
A_X K_X\!\left(\frac{t-t_0}{\tau_X}\right)
+
n(t).
\]

For detector strain data, the phase/sign can be event-dependent, so the practical
complex form is

\[
r_X(t)
=
A_X e^{i\phi_X}
K_X\!\left(\frac{t-t_0}{\tau_X}\right)
+
n(t).
\]

The first search should focus on residual-envelope stacking rather than a new
phase-coherent oscillatory mode.

## First-test free parameters

The first observational model has the nuisance parameters

\[
A_X,\quad t_0,\quad \tau_X,\quad \phi_X .
\]

The shape weights and rate ratios are fixed:

\[
0.8340262441,\quad
0.1613211871,\quad
0.0045930762,\ldots
\]

and

\[
1,\quad
2.2804425096,\quad
3.7432951884,\quad
5.3494810906,\ldots
\]

## Deferred refinement

Mode-dependent \(c_n\) is deferred until the projection bath is explicitly
derived. A mode-dependent closure requires the full matrix

\[
\mathcal C_X^{\rm eff}(\omega_\ast)
=
-
\left.
\partial_\omega
{\rm Im}\Sigma_X^R(\omega)
\right|_{\omega=\omega_\ast},
\]

and generally leads to a generalized relaxation eigenproblem rather than a
simple mode-by-mode decay law.

## Tester

The regression tester for this first-test kernel is

\[
\texttt{scripts/ringdown\_restoration\_kernel\_tester\_v10.py}.
\]

It verifies the radial spectrum, parity selection rule, overlap weights,
capture fractions, and common-scale kernel.
