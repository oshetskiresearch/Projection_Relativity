#!/usr/bin/env python3
"""
ringdown_restoration_kernel_tester_v10.py

Projection Relativity finite-core restoration-kernel tester.

Purpose
-------
This tester verifies the PR-native common-scale ringdown restoration kernel:
    O_X = -d^2/dw^2 + 1 + w^2 + (3/4) w^4
    D_X = -2 d^2/dw^2 - 2 w^2 - 3 w^4

It checks:
    1. the radial spectrum of O_X;
    2. the even-parity dilation selection rule S_{2k+1}=0;
    3. the dilation-overlap weights;
    4. the common-scale kernel K_X(u);
    5. the two-mode and three-mode capture fractions.

The first observational model uses a common continuum/friction scale:
    C_X^eff = c0 I
so that only the physical timescale tau_X is left free, while the kernel shape
is fixed.

No observational GW data are used here. This is a theory-kernel regression test.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from scipy.linalg import eigh
except Exception as exc:  # pragma: no cover
    raise RuntimeError("scipy is required for this tester") from exc


@dataclass(frozen=True)
class Expected:
    lambda0: float = 2.322872581463
    lambda1: float = 5.375889248196
    lambda2: float = 9.083870917219
    lambda4: float = 17.740940593604
    mu2_gap: float = 3.053016666732
    mu2_dil: float = 6.760998335756
    w2: float = 0.8340262441
    w4: float = 0.1613211871
    w6: float = 0.0045930762
    w8: float = 0.0000590010
    two_mode_capture: float = 0.9953474312
    three_mode_capture: float = 0.9999405074
    rate4_over_rate2: float = 2.2804425096
    rate6_over_rate2: float = 3.7432951884


def build_ho_operators(n_basis: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return identity, x, x^2, p^2 in a harmonic-oscillator basis.

    We use dimensionless units with
        x = (a + a†)/sqrt(2)
        p = i(a† - a)/sqrt(2)
    so that p^2 + x^2 has eigenvalues 2n+1 in the oscillator basis.
    """
    a = np.zeros((n_basis, n_basis), dtype=float)
    for n in range(1, n_basis):
        a[n - 1, n] = math.sqrt(n)
    adag = a.T

    x = (a + adag) / math.sqrt(2.0)
    x2 = x @ x
    # p^2 = H_osc - x^2, with H_osc = diag(2n+1)
    h_osc = np.diag([2 * n + 1 for n in range(n_basis)])
    p2 = h_osc - x2
    ident = np.eye(n_basis)
    return ident, x, x2, p2


def compute_spectrum(n_basis: int = 180) -> dict:
    ident, x, x2, p2 = build_ho_operators(n_basis)
    x4 = x2 @ x2

    # PR radial branch operator and finite-core dilation operator
    OX = p2 + ident + x2 + 0.75 * x4
    DX = 2.0 * p2 - 2.0 * x2 - 3.0 * x4

    evals, evecs = eigh(OX)
    order = np.argsort(evals)
    evals = evals[order]
    evecs = evecs[:, order]

    # Fix eigenvector signs for reproducibility.
    for i in range(evecs.shape[1]):
        j = np.argmax(np.abs(evecs[:, i]))
        if evecs[j, i] < 0:
            evecs[:, i] *= -1.0

    u0 = evecs[:, 0]
    source_vec = DX @ u0

    overlaps = evecs.T @ source_vec
    mu2 = evals - evals[0]

    return {
        "n_basis": n_basis,
        "OX": OX,
        "DX": DX,
        "evals": evals,
        "evecs": evecs,
        "mu2": mu2,
        "overlaps": overlaps,
        "source_norm2": float(np.dot(source_vec, source_vec)),
        "virial_S0": float(overlaps[0]),
    }


def make_mode_table(data: dict, max_mode: int = 14) -> pd.DataFrame:
    evals = data["evals"]
    mu2 = data["mu2"]
    overlaps = data["overlaps"]

    # Normalize over all excited states. S0 is zero by the virial theorem up to numerical precision.
    weight_raw = np.abs(overlaps) ** 2
    denom = np.sum(weight_raw[1:])
    weights = weight_raw / denom

    rows = []
    for n in range(max_mode + 1):
        rows.append(
            {
                "mode_n": n,
                "parity_expected": "even" if n % 2 == 0 else "odd",
                "lambda_n": evals[n],
                "mu_n2": mu2[n],
                "S_n": overlaps[n],
                "abs_S_n": abs(overlaps[n]),
                "raw_weight": weight_raw[n],
                "normalized_weight": weights[n],
                "rate_ratio_to_n2": mu2[n] / mu2[2] if n >= 1 and mu2[2] != 0 else np.nan,
            }
        )
    return pd.DataFrame(rows)


def common_scale_kernel(mode_df: pd.DataFrame, u_grid: np.ndarray) -> pd.DataFrame:
    # Use even modes n>=2 only. Renormalize over the included even weights.
    evens = mode_df[(mode_df["mode_n"] >= 2) & (mode_df["mode_n"] % 2 == 0)].copy()
    evens["kernel_weight"] = evens["normalized_weight"] / evens["normalized_weight"].sum()
    evens["scaled_rate"] = evens["mu_n2"] / float(evens.loc[evens["mode_n"] == 2, "mu_n2"].iloc[0])

    K = np.zeros_like(u_grid, dtype=float)
    for _, row in evens.iterrows():
        K += row["kernel_weight"] * np.exp(-row["scaled_rate"] * u_grid)

    df = pd.DataFrame({"u": u_grid, "K_full_even": K})
    # Add two-mode and three-mode versions for test comparisons.
    for label, modes in [("K_2_4", [2, 4]), ("K_2_4_6", [2, 4, 6])]:
        sub = evens[evens["mode_n"].isin(modes)].copy()
        sub["kw"] = sub["normalized_weight"] / sub["normalized_weight"].sum()
        Ksub = np.zeros_like(u_grid, dtype=float)
        for _, row in sub.iterrows():
            Ksub += row["kw"] * np.exp(-row["scaled_rate"] * u_grid)
        df[label] = Ksub
    return df


def crossing_time(u: np.ndarray, y: np.ndarray, target: float) -> float:
    # y is monotone decreasing from 1. Return linear-interpolated crossing.
    idx = np.where(y <= target)[0]
    if len(idx) == 0:
        return float("nan")
    i = int(idx[0])
    if i == 0:
        return float(u[0])
    u0, u1 = u[i - 1], u[i]
    y0, y1 = y[i - 1], y[i]
    if y1 == y0:
        return float(u1)
    return float(u0 + (target - y0) * (u1 - u0) / (y1 - y0))


def make_results(data: dict, mode_df: pd.DataFrame, kernel_df: pd.DataFrame) -> pd.DataFrame:
    exp = Expected()
    even = mode_df[(mode_df["mode_n"] >= 2) & (mode_df["mode_n"] % 2 == 0)]
    w = {int(r["mode_n"]): float(r["normalized_weight"]) for _, r in mode_df.iterrows()}
    mu = {int(r["mode_n"]): float(r["mu_n2"]) for _, r in mode_df.iterrows()}

    # Selection-rule diagnostics
    max_odd_overlap = float(mode_df[(mode_df["mode_n"] % 2 == 1) & (mode_df["mode_n"] <= 13)]["abs_S_n"].max())
    two_capture = float(w[2] + w[4])
    three_capture = float(w[2] + w[4] + w[6])

    checks = [
        ("lambda0", data["evals"][0], exp.lambda0, 5e-10),
        ("lambda1", data["evals"][1], exp.lambda1, 2e-9),
        ("lambda2", data["evals"][2], exp.lambda2, 3e-9),
        ("lambda4", data["evals"][4], exp.lambda4, 5e-9),
        ("mu_min2_lambda1_minus_lambda0", data["mu2"][1], exp.mu2_gap, 2e-9),
        ("mu_dil2_lambda2_minus_lambda0", data["mu2"][2], exp.mu2_dil, 3e-9),
        ("virial_overlap_S0_zero", abs(data["virial_S0"]), 0.0, 5e-9),
        ("odd_overlap_selection_rule", max_odd_overlap, 0.0, 5e-9),
        ("weight_n2", w[2], exp.w2, 5e-7),
        ("weight_n4", w[4], exp.w4, 5e-7),
        ("weight_n6", w[6], exp.w6, 5e-7),
        ("weight_n8", w[8], exp.w8, 5e-7),
        ("two_mode_capture_n2_n4", two_capture, exp.two_mode_capture, 1e-6),
        ("three_mode_capture_n2_n4_n6", three_capture, exp.three_mode_capture, 1e-6),
        ("rate4_over_rate2", mu[4] / mu[2], exp.rate4_over_rate2, 5e-7),
        ("rate6_over_rate2", mu[6] / mu[2], exp.rate6_over_rate2, 5e-7),
        ("kernel_K0_full_even", float(kernel_df["K_full_even"].iloc[0]), 1.0, 1e-12),
    ]

    rows = []
    for name, got, expected, tol in checks:
        err = abs(got - expected)
        rows.append(
            {
                "check": name,
                "status": "PASS" if err <= tol else "FAIL",
                "got": got,
                "expected": expected,
                "abs_error": err,
                "tolerance": tol,
            }
        )
    return pd.DataFrame(rows)


def plot_kernel(kernel_df: pd.DataFrame, out_png: Path, out_pdf: Path) -> None:
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    ax.plot(kernel_df["u"], kernel_df["K_full_even"], label="full even kernel")
    ax.plot(kernel_df["u"], kernel_df["K_2_4"], linestyle="--", label="two-mode n=2,4")
    ax.plot(kernel_df["u"], kernel_df["K_2_4_6"], linestyle=":", label="three-mode n=2,4,6")
    ax.set_xlabel("scaled restoration time u = (t - t0) / tau_X")
    ax.set_ylabel("normalized residual envelope K_X(u)")
    ax.set_title("PR finite-core restoration kernel")
    ax.set_yscale("log")
    ax.set_ylim(1e-3, 1.05)
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_png, dpi=180)
    fig.savefig(out_pdf)
    plt.close(fig)


def main() -> int:
    root = Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name == "scripts" else Path.cwd()
    results_dir = root / "results" / "pr_ringdown_restoration"
    plots_dir = root / "plots" / "pr_ringdown_restoration"
    results_dir.mkdir(parents=True, exist_ok=True)
    plots_dir.mkdir(parents=True, exist_ok=True)

    data = compute_spectrum(n_basis=180)
    mode_df = make_mode_table(data, max_mode=14)

    u_grid = np.linspace(0.0, 6.0, 1201)
    kernel_df = common_scale_kernel(mode_df, u_grid)

    results_df = make_results(data, mode_df, kernel_df)

    # Useful shape crossings.
    shape_rows = []
    for target, name in [(0.5, "half_life"), (math.exp(-1), "e_fold"), (0.1, "ten_percent"), (0.01, "one_percent")]:
        shape_rows.append(
            {
                "quantity": name,
                "target_K": target,
                "u_crossing_full_even": crossing_time(kernel_df["u"].to_numpy(), kernel_df["K_full_even"].to_numpy(), target),
                "u_crossing_two_mode": crossing_time(kernel_df["u"].to_numpy(), kernel_df["K_2_4"].to_numpy(), target),
                "u_crossing_three_mode": crossing_time(kernel_df["u"].to_numpy(), kernel_df["K_2_4_6"].to_numpy(), target),
            }
        )
    shape_df = pd.DataFrame(shape_rows)

    mode_df.to_csv(results_dir / "ringdown_restoration_kernel_tester_v10_modes.csv", index=False)
    kernel_df.to_csv(results_dir / "ringdown_restoration_kernel_tester_v10_kernel.csv", index=False)
    results_df.to_csv(results_dir / "ringdown_restoration_kernel_tester_v10_results.csv", index=False)
    shape_df.to_csv(results_dir / "ringdown_restoration_kernel_tester_v10_shape_times.csv", index=False)

    plot_kernel(
        kernel_df,
        plots_dir / "ringdown_restoration_kernel_tester_v10_kernel.png",
        plots_dir / "ringdown_restoration_kernel_tester_v10_kernel.pdf",
    )

    n_pass = int((results_df["status"] == "PASS").sum())
    n_total = len(results_df)
    print(f"ringdown_restoration_kernel_tester_v10: {n_pass}/{n_total} checks passed")
    if n_pass != n_total:
        print(results_df[results_df["status"] != "PASS"].to_string(index=False))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
