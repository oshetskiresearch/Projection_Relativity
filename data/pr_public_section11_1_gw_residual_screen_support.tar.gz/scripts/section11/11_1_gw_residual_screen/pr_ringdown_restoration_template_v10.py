"""Projection Relativity finite-core restoration residual template v10.

This module implements the first observational ringdown-restoration interface.
It does not fit or generate Kerr modes. It assumes a full linear/nonlinear Kerr
model has already been subtracted from detector strain and provides the PR
finite-core restoration residual template

    r_X(t) = A exp(i phi) K_X((t - t0)/tau_X)

with K_X fixed by the parity-even finite-core dilation kernel.

The default kernel is the common-scale kernel locked by the ringdown
restoration calculations:

    K_X(u) = sum_i w_i exp(-r_i u),  u >= 0,

where the leading n=2 channel sets r_2 = 1.  The mode weights and ratios are
not fit parameters in the first-test model.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Literal, Sequence
import math
import numpy as np

ModeSet = Literal["two", "three", "full"]


@dataclass(frozen=True)
class RestorationMode:
    """One mode in the common-scale finite-core restoration kernel."""

    n: int
    weight: float
    mu2: float
    rate_ratio: float


# Closure-grade common-scale kernel values from the Step 2/3 calculation.
# rate_ratio = mu_n^2 / mu_2^2.
_MODES_FULL: tuple[RestorationMode, ...] = (
    RestorationMode(2, 0.8340262441, 6.7609983358, 1.0),
    RestorationMode(4, 0.1613211871, 15.4180680121, 2.2804425096),
    RestorationMode(6, 0.0045930762, 25.3084125388, 3.7432951884),
    RestorationMode(8, 0.0000590010, 36.1678327506, 5.3494810906),
    RestorationMode(10, 0.0000004916, 47.8415760890, 7.0751748994),
)


def get_modes(mode_set: ModeSet = "three", normalize: bool = True) -> tuple[RestorationMode, ...]:
    """Return the requested PR restoration mode set.

    Parameters
    ----------
    mode_set:
        ``"two"`` uses n=2,4 only; ``"three"`` uses n=2,4,6; ``"full"`` uses
        the stored n=2,4,6,8,10 set.
    normalize:
        If True, renormalizes the selected weights so K(0)=1 for the selected
        truncation.  If False, returns the original weights; K(0) then equals
        the captured source fraction of that truncation.
    """

    if mode_set == "two":
        modes = _MODES_FULL[:2]
    elif mode_set == "three":
        modes = _MODES_FULL[:3]
    elif mode_set == "full":
        modes = _MODES_FULL
    else:
        raise ValueError(f"Unknown mode_set {mode_set!r}; expected 'two', 'three', or 'full'.")

    if not normalize:
        return modes

    total = sum(m.weight for m in modes)
    if not math.isfinite(total) or total <= 0:
        raise ValueError("Mode weights must have a positive finite sum.")

    return tuple(RestorationMode(m.n, m.weight / total, m.mu2, m.rate_ratio) for m in modes)


def restoration_kernel(
    u: float | Sequence[float] | np.ndarray,
    mode_set: ModeSet = "three",
    causal: bool = True,
    normalize: bool = True,
) -> np.ndarray:
    """Evaluate the dimensionless PR finite-core restoration kernel K_X(u).

    Parameters
    ----------
    u:
        Dimensionless restoration time, u = (t - t0) / tau_X.
    mode_set:
        Mode truncation to use.
    causal:
        If True, K(u<0)=0.  If False, negative u values are evaluated by the
        exponential expression.  For physical residual templates, use True.
    normalize:
        If True, selected weights are normalized so K(0)=1.
    """

    arr = np.asarray(u, dtype=float)
    out = np.zeros_like(arr, dtype=float)
    eval_arr = np.maximum(arr, 0.0) if causal else arr
    for mode in get_modes(mode_set, normalize=normalize):
        out += mode.weight * np.exp(-mode.rate_ratio * eval_arr)
    if causal:
        out = np.where(arr >= 0.0, out, 0.0)
    return out


def residual_template(
    t: float | Sequence[float] | np.ndarray,
    amplitude: float = 1.0,
    t0: float = 0.0,
    tau_x: float = 1.0,
    phi: float = 0.0,
    mode_set: ModeSet = "three",
    causal: bool = True,
    complex_output: bool = True,
    normalize: bool = True,
) -> np.ndarray:
    """Generate the PR finite-core residual template r_X(t).

    r_X(t) = amplitude * exp(i phi) * K_X((t - t0)/tau_x).

    This is intended to be fit to residuals after full Kerr subtraction, not to
    raw strain.  ``tau_x`` must be positive.
    """

    if tau_x <= 0 or not math.isfinite(tau_x):
        raise ValueError("tau_x must be a positive finite number.")
    if not math.isfinite(amplitude) or not math.isfinite(t0) or not math.isfinite(phi):
        raise ValueError("amplitude, t0, and phi must be finite.")

    arr = np.asarray(t, dtype=float)
    u = (arr - t0) / tau_x
    kernel = restoration_kernel(u, mode_set=mode_set, causal=causal, normalize=normalize)
    phase = complex(math.cos(phi), math.sin(phi))
    signal = amplitude * phase * kernel
    if complex_output:
        return signal
    return signal.real


def envelope_template(
    t: float | Sequence[float] | np.ndarray,
    amplitude: float = 1.0,
    t0: float = 0.0,
    tau_x: float = 1.0,
    mode_set: ModeSet = "three",
    causal: bool = True,
    normalize: bool = True,
) -> np.ndarray:
    """Return the positive residual envelope |r_X(t)|."""

    return np.abs(
        residual_template(
            t,
            amplitude=amplitude,
            t0=t0,
            tau_x=tau_x,
            phi=0.0,
            mode_set=mode_set,
            causal=causal,
            complex_output=True,
            normalize=normalize,
        )
    )


def template_matrix(
    t: Sequence[float] | np.ndarray,
    tau_grid: Iterable[float],
    t0_grid: Iterable[float] = (0.0,),
    mode_set: ModeSet = "three",
    normalize: bool = True,
) -> np.ndarray:
    """Build a real design matrix for linear-amplitude residual-envelope fits.

    Columns correspond to K_X((t - t0)/tau_x) for each (t0, tau_x) pair.  This
    can be used for quick matched-filter or linear regression scans after a
    Kerr-subtracted residual is supplied.
    """

    arr = np.asarray(t, dtype=float)
    columns = []
    for t0 in t0_grid:
        for tau_x in tau_grid:
            columns.append(
                restoration_kernel((arr - float(t0)) / float(tau_x), mode_set=mode_set, normalize=normalize)
            )
    if not columns:
        raise ValueError("At least one tau_x value is required.")
    return np.vstack(columns).T


def shape_times(mode_set: ModeSet = "three", levels: Sequence[float] = (0.5, math.exp(-1), 0.1, 0.01)) -> dict[float, float]:
    """Return u values where K_X(u) falls to requested levels.

    Uses bisection on u in [0, 100].  Levels must lie in (0, 1].
    """

    result: dict[float, float] = {}
    for level in levels:
        if not (0.0 < level <= 1.0):
            raise ValueError("levels must be in (0, 1].")
        if level == 1.0:
            result[level] = 0.0
            continue
        lo, hi = 0.0, 100.0
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            val = float(restoration_kernel(mid, mode_set=mode_set, causal=True, normalize=True))
            if val > level:
                lo = mid
            else:
                hi = mid
        result[level] = 0.5 * (lo + hi)
    return result


__all__ = [
    "RestorationMode",
    "get_modes",
    "restoration_kernel",
    "residual_template",
    "envelope_template",
    "template_matrix",
    "shape_times",
]
