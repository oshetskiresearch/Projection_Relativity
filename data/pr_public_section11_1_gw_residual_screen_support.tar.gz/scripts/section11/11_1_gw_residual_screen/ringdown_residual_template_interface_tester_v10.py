"""Regression tester for PR ringdown residual template interface v10."""

from __future__ import annotations

import csv
import math
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
RESULTS = ROOT / "results" / "pr_ringdown_restoration"
PLOTS = ROOT / "plots" / "pr_ringdown_restoration"

sys.path.insert(0, str(SCRIPTS))
from pr_ringdown_restoration_template_v10 import (  # noqa: E402
    get_modes,
    restoration_kernel,
    residual_template,
    envelope_template,
    template_matrix,
    shape_times,
)

RESULTS.mkdir(parents=True, exist_ok=True)
PLOTS.mkdir(parents=True, exist_ok=True)


def check(name: str, value: float, expected: float, tol: float, rows: list[dict]) -> None:
    passed = abs(value - expected) <= tol
    rows.append(
        {
            "check": name,
            "value": value,
            "expected": expected,
            "tolerance": tol,
            "abs_error": abs(value - expected),
            "status": "PASS" if passed else "FAIL",
        }
    )


def check_bool(name: str, passed: bool, rows: list[dict], value: str = "") -> None:
    rows.append(
        {
            "check": name,
            "value": value,
            "expected": "True",
            "tolerance": "",
            "abs_error": "",
            "status": "PASS" if passed else "FAIL",
        }
    )


def main() -> int:
    rows: list[dict] = []

    # Kernel normalization and causality.
    check("K_three(0)=1", float(restoration_kernel(0.0, mode_set="three")), 1.0, 1e-12, rows)
    check("K_two(0)=1", float(restoration_kernel(0.0, mode_set="two")), 1.0, 1e-12, rows)
    check("K_full(0)=1", float(restoration_kernel(0.0, mode_set="full")), 1.0, 1e-12, rows)
    check("K(u<0)=0 causal", float(restoration_kernel(-0.1, mode_set="three", causal=True)), 0.0, 1e-15, rows)
    check_bool("K is monotone decreasing over u in [0, 8]", bool(np.all(np.diff(restoration_kernel(np.linspace(0, 8, 1000))) <= 1e-14)), rows)

    # Mode weights and ratios.
    modes_three = get_modes("three", normalize=True)
    expected_three = [
        (2, 0.8340758654418323, 1.0),
        (4, 0.1613307850878649, 2.2804425096),
        (6, 0.0045933494703027, 3.7432951884),
    ]
    for mode, (exp_n, exp_w, exp_r) in zip(modes_three, expected_three):
        check_bool(f"mode n={exp_n} retained", mode.n == exp_n, rows, value=str(mode.n))
        check(f"mode n={exp_n} normalized weight", mode.weight, exp_w, 5e-10, rows)
        check(f"mode n={exp_n} rate ratio", mode.rate_ratio, exp_r, 5e-10, rows)

    # Unnormalized capture fractions.
    check("two-mode captured source weight", sum(m.weight for m in get_modes("two", normalize=False)), 0.9953474312, 5e-10, rows)
    check("three-mode captured source weight", sum(m.weight for m in get_modes("three", normalize=False)), 0.9999405074, 5e-10, rows)

    # Residual template behavior.
    t = np.array([-1.0, 0.0, 0.5, 1.0])
    amp = 2.0
    phi = 0.7
    y = residual_template(t, amplitude=amp, t0=0.0, tau_x=1.0, phi=phi, mode_set="three")
    check("causal residual before onset is zero real", float(y[0].real), 0.0, 1e-15, rows)
    check("causal residual before onset is zero imag", float(y[0].imag), 0.0, 1e-15, rows)
    check("residual at onset real", float(y[1].real), amp * math.cos(phi), 1e-12, rows)
    check("residual at onset imag", float(y[1].imag), amp * math.sin(phi), 1e-12, rows)
    env = envelope_template(t, amplitude=amp, t0=0.0, tau_x=1.0, mode_set="three")
    check("envelope at onset equals amplitude", float(env[1]), amp, 1e-12, rows)

    # Design matrix shape.
    mat = template_matrix(np.linspace(0, 1, 8), tau_grid=[0.5, 1.0, 2.0], t0_grid=[0.0, 0.1])
    check_bool("template matrix has expected shape 8x6", mat.shape == (8, 6), rows, value=str(mat.shape))

    # Shape-time targets from the locked three-mode normalized kernel.
    st = shape_times("three")
    check("u half-life K=0.5", st[0.5], 0.5987412019, 5e-10, rows)
    check("u e-fold K=e^-1", st[math.exp(-1)], 0.8798419698, 5e-10, rows)
    check("u K=0.1", st[0.1], 2.1336803222, 5e-10, rows)
    check("u K=0.01", st[0.01], 4.4244091857, 5e-10, rows)

    # Save check results.
    results_df = pd.DataFrame(rows)
    results_path = RESULTS / "ringdown_residual_template_interface_tester_v10_results.csv"
    results_df.to_csv(results_path, index=False)

    # Save mode tables.
    mode_rows = []
    for mode_set in ["two", "three", "full"]:
        for normalize in [False, True]:
            for mode in get_modes(mode_set, normalize=normalize):
                mode_rows.append(
                    {
                        "mode_set": mode_set,
                        "normalize": normalize,
                        "n": mode.n,
                        "weight": mode.weight,
                        "mu2": mode.mu2,
                        "rate_ratio": mode.rate_ratio,
                    }
                )
    mode_df = pd.DataFrame(mode_rows)
    mode_path = RESULTS / "ringdown_residual_template_interface_v10_modes.csv"
    mode_df.to_csv(mode_path, index=False)

    # Save kernel table.
    u = np.linspace(-1.0, 8.0, 901)
    kernel_df = pd.DataFrame(
        {
            "u": u,
            "K_two": restoration_kernel(u, mode_set="two"),
            "K_three": restoration_kernel(u, mode_set="three"),
            "K_full": restoration_kernel(u, mode_set="full"),
        }
    )
    kernel_path = RESULTS / "ringdown_residual_template_interface_v10_kernel.csv"
    kernel_df.to_csv(kernel_path, index=False)

    # Save example physical template table.
    t_phys = np.linspace(-0.01, 0.05, 1201)
    example = residual_template(t_phys, amplitude=1.0, t0=0.0, tau_x=0.008, phi=0.4, mode_set="three")
    example_df = pd.DataFrame(
        {
            "t_s": t_phys,
            "u": t_phys / 0.008,
            "template_real": example.real,
            "template_imag": example.imag,
            "template_abs": np.abs(example),
        }
    )
    example_path = RESULTS / "ringdown_residual_template_interface_v10_example_physical_template.csv"
    example_df.to_csv(example_path, index=False)

    # Save shape times.
    shape_df = pd.DataFrame([{"level": level, "u": val} for level, val in st.items()])
    shape_path = RESULTS / "ringdown_residual_template_interface_v10_shape_times.csv"
    shape_df.to_csv(shape_path, index=False)

    # Plots.
    fig = plt.figure(figsize=(7.2, 4.6))
    ax = fig.add_subplot(111)
    mask = u >= 0
    ax.plot(u[mask], kernel_df.loc[mask, "K_two"], label="two-mode")
    ax.plot(u[mask], kernel_df.loc[mask, "K_three"], label="three-mode")
    ax.plot(u[mask], kernel_df.loc[mask, "K_full"], label="full stored")
    ax.set_xlabel("scaled restoration time u")
    ax.set_ylabel("K_X(u)")
    ax.set_yscale("log")
    ax.set_title("PR finite-core restoration residual kernel")
    ax.legend()
    fig.tight_layout()
    fig.savefig(PLOTS / "ringdown_residual_template_interface_v10_kernel.png", dpi=220)
    fig.savefig(PLOTS / "ringdown_residual_template_interface_v10_kernel.pdf")
    plt.close(fig)

    fig = plt.figure(figsize=(7.2, 4.6))
    ax = fig.add_subplot(111)
    ax.plot(t_phys * 1000.0, example_df["template_real"], label="real")
    ax.plot(t_phys * 1000.0, example_df["template_imag"], label="imag")
    ax.plot(t_phys * 1000.0, example_df["template_abs"], label="envelope")
    ax.set_xlabel("time after Kerr-subtraction reference [ms]")
    ax.set_ylabel("normalized residual template")
    ax.set_title("Example PR residual template: tau_X=8 ms, phi=0.4")
    ax.legend()
    fig.tight_layout()
    fig.savefig(PLOTS / "ringdown_residual_template_interface_v10_example.png", dpi=220)
    fig.savefig(PLOTS / "ringdown_residual_template_interface_v10_example.pdf")
    plt.close(fig)

    failures = int((results_df["status"] != "PASS").sum())
    total = len(results_df)
    summary_path = RESULTS / "ringdown_residual_template_interface_v10_summary.txt"
    summary_path.write_text(f"{total - failures}/{total} checks passed\n", encoding="utf-8")

    print(f"{total - failures}/{total} checks passed")
    print(f"results: {results_path}")
    print(f"modes:   {mode_path}")
    print(f"kernel:  {kernel_path}")
    print(f"example: {example_path}")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
