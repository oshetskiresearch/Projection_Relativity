#!/usr/bin/env python3
"""
Projection Relativity compact fine-structure closure, 20+ digit audit.

Purpose
-------
Print the boundary-resolved compact fine-structure normalization to 20+ digits
without using the measured low-energy fine-structure constant as an input.

The script reports two layers:

1. Exact trace-word closure arithmetic:
   T_A=1/4, T_X=3/4, D_A=1-T_A^3-T_A^4,
   N_bc=1+T_A^3+T_A^4+T_X(T_A^5-T_A^8),
   c_bc=T_X[1+T_A^2-T_A^6 N_bc/D_A].

2. Boundary-resolved compact stiffness output:
   alpha_PR,bc^{-1}=4*pi*q_bc, where q_bc=R_A^{-2} is the compact
   phase stiffness produced by the finite-rank compact boundary map.

No CODATA/laboratory alpha value is used anywhere in the calculation below.
The default q_bc is the stored PR finite-rank boundary-output value used in the
paper audit. To audit a new nonperturbative radial solve, pass --q-bc or
--lambda0 --lambda1 --lambda3 --p1.
"""
from __future__ import annotations

import argparse
import json
from decimal import Decimal, getcontext
from pathlib import Path

import mpmath as mp


def mpq(n: int, d: int) -> mp.mpf:
    return mp.mpf(n) / mp.mpf(d)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dps", type=int, default=100, help="mpmath decimal precision")
    ap.add_argument("--digits", type=int, default=20, help="digits to display after decimal for alpha inverse")
    ap.add_argument("--outdir", default="results/compact_phase")
    ap.add_argument(
        "--q-bc",
        default="10.905007182855216",
        help="Boundary-resolved compact stiffness q_bc=R_A^{-2}; derived PR boundary-map output, not lab alpha.",
    )
    ap.add_argument("--lambda0", default=None, help="Optional radial lambda0 for p1 reconstruction")
    ap.add_argument("--lambda1", default=None, help="Optional radial lambda1 for p1 reconstruction")
    ap.add_argument("--lambda3", default=None, help="Optional radial lambda3 for p1 reconstruction")
    ap.add_argument("--p1", default=None, help="Optional finite-rank leakage p1 for q=p1*q1+(1-p1)*q3")
    args = ap.parse_args()

    mp.mp.dps = args.dps
    getcontext().prec = args.dps

    TA = mpq(1, 4)
    TX = mpq(3, 4)
    DA = 1 - TA**3 - TA**4
    Nbc = 1 + TA**3 + TA**4 + TX * (TA**5 - TA**8)
    cbc = TX * (1 + TA**2 - TA**6 * Nbc / DA)

    q_bc = mp.mpf(args.q_bc)
    source = "direct boundary compact stiffness q_bc"

    if all(v is not None for v in [args.lambda0, args.lambda1, args.lambda3, args.p1]):
        lam0 = mp.mpf(args.lambda0)
        lam1 = mp.mpf(args.lambda1)
        lam3 = mp.mpf(args.lambda3)
        p1 = mp.mpf(args.p1)
        q1 = lam1 - lam0
        q3 = lam3 - lam0
        q_bc = p1 * q1 + (1 - p1) * q3
        source = "reconstructed from radial eigenvalues and p1 leakage"
    else:
        lam0 = lam1 = lam3 = p1 = q1 = q3 = None

    alpha_inv = 4 * mp.pi * q_bc
    alpha = 1 / alpha_inv
    RA = 1 / mp.sqrt(q_bc)
    CA = q_bc / mp.mpf("3.052966743096")

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    def nstr(x, n=80):
        return mp.nstr(x, n)

    alpha_fixed = mp.nstr(alpha_inv, args.dps)
    display = nstr(alpha_inv, args.digits + 4)

    report = {
        "precision_dps": args.dps,
        "no_laboratory_alpha_input": True,
        "trace_inputs": {"T_A": "1/4", "T_X": "3/4"},
        "D_A": nstr(DA),
        "N_bc": nstr(Nbc),
        "c_bc": nstr(cbc),
        "c_bc_exact_fraction": "3354902985/4211081216",
        "q_bc_R_A_inverse_squared": nstr(q_bc),
        "q_source": source,
        "R_A": nstr(RA),
        "C_A_using_mu2min_reference": nstr(CA),
        "alpha_PR_bc_inverse": nstr(alpha_inv, 90),
        "alpha_PR_bc": nstr(alpha, 90),
        "display_alpha_inverse": display,
    }
    if lam0 is not None:
        report.update({
            "lambda0": nstr(lam0), "lambda1": nstr(lam1), "lambda3": nstr(lam3),
            "q1_lambda1_minus_lambda0": nstr(q1),
            "q3_lambda3_minus_lambda0": nstr(q3),
            "p1": nstr(p1),
        })

    (outdir / "fsc_20digit_precision_report.json").write_text(json.dumps(report, indent=2))
    with open(outdir / "fsc_20digit_precision_summary.csv", "w") as f:
        f.write("quantity,value\n")
        for k in ["D_A", "N_bc", "c_bc", "q_bc_R_A_inverse_squared", "R_A", "C_A_using_mu2min_reference", "alpha_PR_bc_inverse", "alpha_PR_bc"]:
            f.write(f"{k},{report[k]}\n")

    print("PR compact fine-structure closure audit")
    print("No CODATA/laboratory alpha input used:", report["no_laboratory_alpha_input"])
    print("T_A = 1/4, T_X = 3/4")
    print("D_A  =", report["D_A"])
    print("N_bc =", report["N_bc"])
    print("c_bc =", report["c_bc"], "= 3354902985/4211081216")
    print("q_bc = R_A^{-2} =", report["q_bc_R_A_inverse_squared"])
    print("alpha_PR,bc^{-1} =", report["alpha_PR_bc_inverse"])
    print(f"alpha_PR,bc^{{-1}} displayed to ~{args.digits} digits:", report["display_alpha_inverse"])
    print("Report:", outdir / "fsc_20digit_precision_report.json")

if __name__ == "__main__":
    main()
