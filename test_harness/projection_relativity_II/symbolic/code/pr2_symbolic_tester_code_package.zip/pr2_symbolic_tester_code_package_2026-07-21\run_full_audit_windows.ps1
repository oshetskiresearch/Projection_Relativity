$ErrorActionPreference = "Stop"

$harnessRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $harnessRoot

if ($env:PR2_SKIP_GITHUB_FETCH -eq "1") {
    Write-Host "Skipping GitHub source fetch because PR2_SKIP_GITHUB_FETCH=1."
} else {
    & "$harnessRoot\fetch_github_source.ps1"
}

$pythonCandidates = @()
if ($env:PR2_PYTHON) {
    $pythonCandidates += $env:PR2_PYTHON
}

$pathPython = Get-Command python -ErrorAction SilentlyContinue
if ($pathPython) {
    $pythonCandidates += $pathPython.Source
}

$pathPy = Get-Command py -ErrorAction SilentlyContinue
if ($pathPy) {
    $pythonCandidates += $pathPy.Source
}

$pythonExe = $pythonCandidates |
    Where-Object { $_ -and (Test-Path $_) } |
    Select-Object -First 1

if (-not $pythonExe) {
    Write-Host "Python was not found for equation coverage regeneration."
    Write-Host "Maple can still run, but the generated source audit may be stale."
} else {
    Write-Host "Regenerating source equation coverage with: $pythonExe"
    & $pythonExe "$harnessRoot\scripts\equation_coverage.py"
    & $pythonExe "$harnessRoot\scripts\generate_maple_source_audit.py"
}

& "$harnessRoot\run_maple_windows.ps1"

if ($pythonExe) {
    Write-Host ""
    Write-Host "Regenerating coverage quality report"
    & $pythonExe "$harnessRoot\scripts\coverage_quality.py"
}

Write-Host ""
Write-Host "Full audit artifacts:"
Write-Host "  $harnessRoot\source_equation_coverage.md"
Write-Host "  $harnessRoot\source_equation_inventory.csv"
Write-Host "  $harnessRoot\coverage_quality_report.md"
