$ErrorActionPreference = "Stop"

$harnessRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDir = Join-Path $harnessRoot "source"
$sourceName = "Oshetski_Projection_Relativity_II_Main.tex"
$sourceUrl = "https://raw.githubusercontent.com/oshetskiresearch/Projection_Relativity/main/manuscript/projection_relativity_II/$sourceName"
$sourcePath = Join-Path $sourceDir $sourceName
$manifestPath = Join-Path $sourceDir "github_source_manifest.json"

New-Item -ItemType Directory -Force -Path $sourceDir | Out-Null

Write-Host "Fetching final PR-II manuscript from GitHub:"
Write-Host "  $sourceUrl"
Write-Host "Writing:"
Write-Host "  $sourcePath"

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri $sourceUrl -OutFile $sourcePath

$item = Get-Item -LiteralPath $sourcePath
$hash = (Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash
$manifest = [ordered]@{
    source_url = $sourceUrl
    source_file = $sourceName
    source_path = "source/$sourceName"
    sha256 = $hash
    bytes = $item.Length
    fetched_at_utc = (Get-Date).ToUniversalTime().ToString("o")
}

$manifest | ConvertTo-Json | Set-Content -LiteralPath $manifestPath -Encoding UTF8

Write-Host "Fetched source SHA256: $hash"
Write-Host "Wrote manifest:"
Write-Host "  $manifestPath"
