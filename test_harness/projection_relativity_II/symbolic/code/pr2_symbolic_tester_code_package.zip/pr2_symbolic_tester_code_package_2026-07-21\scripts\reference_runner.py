from __future__ import annotations

import cmath
import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"


results: list[dict[str, str]] = []


def add_result(test_id, section, kind, status, actual, expected, error, tolerance, note):
    results.append(
        {
            "id": test_id,
            "section": section,
            "kind": kind,
            "status": status,
            "actual": repr(actual),
            "expected": repr(expected),
            "error": repr(error),
            "tolerance": repr(tolerance),
            "note": note,
        }
    )


def close(test_id, section, actual, expected, tol, note):
    error = abs(actual - expected)
    add_result(test_id, section, "numeric", "PASS" if error <= tol else "FAIL", actual, expected, error, tol, note)


def exact(test_id, section, actual, expected, note):
    add_result(test_id, section, "exact", "PASS" if actual == expected else "FAIL", actual, expected, actual - expected, 0, note)


def truth(test_id, section, condition, note):
    add_result(test_id, section, "predicate", "PASS" if condition else "FAIL", condition, True, 0, 0, note)


def matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]


def madd(a, b):
    return [[a[i][j] + b[i][j] for j in range(len(a[0]))] for i in range(len(a))]


def msub(a, b):
    return [[a[i][j] - b[i][j] for j in range(len(a[0]))] for i in range(len(a))]


def smul(s, a):
    return [[s * a[i][j] for j in range(len(a[0]))] for i in range(len(a))]


def mv(a, v):
    return [sum(a[i][j] * v[j] for j in range(len(v))) for i in range(len(a))]


def dagger(a):
    return [[a[j][i].conjugate() for j in range(len(a))] for i in range(len(a[0]))]


def transpose(a):
    return [[a[j][i] for j in range(len(a))] for i in range(len(a[0]))]


def ident(n):
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]


def trace(a):
    return sum(a[i][i] for i in range(len(a)))


def det2(a):
    return a[0][0] * a[1][1] - a[0][1] * a[1][0]


def max_abs_matrix(a):
    return max(abs(x) for row in a for x in row)


def matclose(test_id, section, actual, expected, tol, note):
    error = max_abs_matrix(msub(actual, expected))
    add_result(test_id, section, "matrix", "PASS" if error <= tol else "FAIL", actual, expected, error, tol, note)


def vecclose(test_id, section, actual, expected, tol, note):
    error = max(abs(a - b) for a, b in zip(actual, expected))
    add_result(test_id, section, "vector", "PASS" if error <= tol else "FAIL", actual, expected, error, tol, note)


def beta_coeffs(nf):
    return (
        11 - 2 * nf / 3,
        102 - 38 * nf / 3,
        2857 / 2 - 5033 * nf / 18 + 325 * nf * nf / 54,
    )


def alpha_3loop(mu, lam, nf):
    b0, b1, b2 = beta_coeffs(nf)
    L = math.log(mu * mu / (lam * lam))
    term1 = 4 * math.pi / (b0 * L)
    term2 = 1 - (b1 / (b0 * b0)) * math.log(L) / L
    term3 = ((b1 * b1) * (math.log(L) ** 2 - math.log(L) - 1) + b0 * b2) / (b0**4 * L * L)
    return term1 * (term2 + term3)


def solve_lambda_3loop(mu, alpha_target, nf):
    lo, hi = 1e-12, 0.999999 * mu
    for _ in range(250):
        mid = (lo + hi) / 2
        if alpha_3loop(mu, mid, nf) < alpha_target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def mass_run_1loop(m1, mu1, mu2, nf, lam):
    a_m = 12 / (33 - 2 * nf)
    return m1 * (alpha_3loop(mu2, lam, nf) / alpha_3loop(mu1, lam, nf)) ** a_m


def ckm_matrix(s12, s23, s13, delta):
    c12 = math.sqrt(1 - s12 * s12)
    c23 = math.sqrt(1 - s23 * s23)
    c13 = math.sqrt(1 - s13 * s13)
    epos = cmath.exp(1j * delta)
    eneg = cmath.exp(-1j * delta)
    return [
        [c12 * c13, s12 * c13, s13 * eneg],
        [-s12 * c23 - c12 * s23 * s13 * epos, c12 * c23 - s12 * s23 * s13 * epos, s23 * c13],
        [s12 * s23 - c12 * c23 * s13 * epos, -c12 * s23 - s12 * c23 * s13 * epos, c23 * c13],
    ]


def abs_matrix(a):
    return [[abs(x) for x in row] for row in a]


def jarlskog(s12, s23, s13, delta):
    c12 = math.sqrt(1 - s12 * s12)
    c23 = math.sqrt(1 - s23 * s23)
    c13 = math.sqrt(1 - s13 * s13)
    return s12 * s23 * s13 * c12 * c23 * c13 * c13 * math.sin(delta)


def run():
    q_bc = 10.905007182855176
    c_bc = 3354902985 / 4211081216
    mu_min2 = 3.052966743096
    alpha_inv = 137.036361812007
    rG = c_bc / q_bc
    Delta = (1 - c_bc) / q_bc
    TY = 1 / 4
    sin2 = TY - Delta
    cos2 = 1 - sin2
    tanW = math.sqrt(sin2 / cos2)
    Xi = q_bc * c_bc * sin2
    yT = math.sqrt(2 / Xi)
    Mpl = 2.4353234593382036e18
    Sbase = math.pi * q_bc + math.log(q_bc / c_bc) + math.log(4 / 3) + (TY - sin2) * (1 + c_bc) / 2
    dS = -0.5 * (1 + 3 * c_bc) * Delta**2
    Stotal = Sbase + dS
    LambdaEW = Mpl * math.exp(-Stotal)
    vEW = LambdaEW * math.sqrt(Xi)
    GF = 1 / (math.sqrt(2) * vEW**2)
    vRef = 246.2196507941374
    GFRef = 1 / (math.sqrt(2) * vRef**2)
    AEW = (1 + 3 * c_bc) / 2
    C1 = 1 - Delta * c_bc / 4
    C2 = 1 - rG * Delta * (1 + c_bc) / 2
    Cconf = (1 + c_bc) / 2

    # SU(2) algebra.
    I = 1j
    sigma1 = [[0, 1], [1, 0]]
    sigma2 = [[0, -I], [I, 0]]
    sigma3 = [[1, 0], [0, -1]]
    T1 = smul(0.5, sigma1)
    T2 = smul(0.5, sigma2)
    T3 = smul(0.5, sigma3)
    Tplus = madd(T1, smul(I, T2))
    Tminus = madd(T1, smul(-I, T2))
    up = [1, 0]
    down = [0, 1]
    matclose("G001", "sec:pr2_nonabelian_generator_algebra", msub(matmul(T1, T2), matmul(T2, T1)), smul(I, T3), 1e-15, "[T1,T2]=iT3")
    matclose("G002", "sec:pr2_nonabelian_generator_algebra", msub(matmul(T2, T3), matmul(T3, T2)), smul(I, T1), 1e-15, "[T2,T3]=iT1")
    matclose("G003", "sec:pr2_nonabelian_generator_algebra", msub(matmul(T3, T1), matmul(T1, T3)), smul(I, T2), 1e-15, "[T3,T1]=iT2")
    close("G004", "sec:pr2_nonabelian_generator_algebra", trace(matmul(T1, T1)).real, 0.5, 1e-15, "Trace normalization for T1")
    close("G005", "sec:pr2_nonabelian_generator_algebra", trace(matmul(T2, T2)).real, 0.5, 1e-15, "Trace normalization for T2")
    close("G006", "sec:pr2_nonabelian_generator_algebra", trace(matmul(T3, T3)).real, 0.5, 1e-15, "Trace normalization for T3")
    close("G007", "sec:pr2_nonabelian_generator_algebra", abs(trace(matmul(T1, T2))), 0, 1e-15, "Off-diagonal trace normalization")
    matclose("G008", "sec:pr2_nonabelian_generator_algebra", madd(madd(matmul(T1, T1), matmul(T2, T2)), matmul(T3, T3)), smul(0.75, ident(2)), 1e-15, "Fundamental Casimir is 3/4 I")
    exact("G009", "sec:pr2_compact_weak_isospin_operator", 0 * (0 + 1), 0, "j=0 spectral value numerator")
    close("G010", "sec:pr2_compact_weak_isospin_operator", 0.5 * 1.5, 0.75, 1e-15, "j=1/2 spectral value numerator")
    exact("G011", "sec:pr2_compact_weak_isospin_operator", 1 * (1 + 1), 2, "j=1 adjoint Casimir")
    vecclose("G012", "sec:pr2_charged_current_topological_ladder", mv(Tplus, down), up, 1e-15, "T+ raises down to up")
    vecclose("G013", "sec:pr2_charged_current_topological_ladder", mv(Tminus, up), down, 1e-15, "T- lowers up to down")
    vecclose("G014", "sec:pr2_charged_current_topological_ladder", mv(Tplus, up), [0, 0], 1e-15, "T+ annihilates up")
    vecclose("G015", "sec:pr2_charged_current_topological_ladder", mv(Tminus, down), [0, 0], 1e-15, "T- annihilates down")
    QY1 = madd(T3, smul(0.5, ident(2)))
    vecclose("G016", "sec:pr2_compact_electroweak_order_direction", mv(QY1, down), [0, 0], 1e-15, "Q annihilates the locking direction")
    matclose("G017", "sec:pr2_charged_current_ladder", msub(matmul(QY1, Tplus), matmul(Tplus, QY1)), Tplus, 1e-15, "[Q,T+]=T+")
    matclose("G018", "sec:pr2_charged_current_ladder", msub(matmul(QY1, Tminus), matmul(Tminus, QY1)), smul(-1, Tminus), 1e-15, "[Q,T-]=-T-")

    # Electroweak structural identities via representative numeric couplings.
    g0, gp0, vv = 0.63, 0.34, 246.0
    M0 = smul(vv**2 / 4, [[g0**2, -g0 * gp0], [-g0 * gp0, gp0**2]])
    MW2s = g0**2 * vv**2 / 4
    MZ2s = (g0**2 + gp0**2) * vv**2 / 4
    cos2s = g0**2 / (g0**2 + gp0**2)
    close("EW001", "sec:pr2_electroweak_connection_mass_ledger", det2(M0), 0, 1e-8, "Neutral mass matrix has zero determinant")
    close("EW002", "sec:pr2_electroweak_connection_mass_ledger", trace(M0), MZ2s, 1e-12, "Nonzero neutral eigenvalue is MZ^2")
    close("EW003", "sec:pr2_tree_level_electroweak_consistency", MW2s / (MZ2s * cos2s), 1, 1e-15, "rho_EW tree-level identity")
    close("EW004", "sec:pr2_charged_weak_projection_fermi_limit", g0**2 / (8 * MW2s), 1 / (2 * vv**2), 1e-20, "Charged Fermi contact coefficient")
    close("EW005", "sec:pr2_neutral_current_projection", (g0**2 + gp0**2) / (8 * MZ2s), 1 / (2 * vv**2), 1e-20, "Neutral-current contact coefficient")
    exact("EW006", "sec:pr2_compact_order_field_counting", (3 + 1) - 1, 3, "Broken compact directions")
    exact("EW007", "sec:pr2_compact_order_field_counting", 4 - 3, 1, "One scalar order-mode remains")
    close("EW008", "sec:pr2_order_mode_gauge_boson_couplings", 2 * MW2s / vv, g0**2 * vv / 2, 1e-14, "hWW coupling ratio")
    close("EW009", "sec:pr2_order_mode_gauge_boson_couplings", 2 * MZ2s / vv, (g0**2 + gp0**2) * vv / 2, 1e-15, "hZZ coupling ratio")

    # Boundary and weak scale.
    close("B001", "sec:pr2_boundary_ledger_electroweak_lift", mu_min2, 3.052966743096, 1e-12, "Radial stiffness gap")
    close("B002", "sec:pr2_boundary_ledger_electroweak_lift", q_bc, 10.905007182855176, 1e-12, "Compact boundary stiffness")
    close("B003", "sec:pr2_boundary_ledger_electroweak_lift", c_bc, 0.796684464847899, 1e-12, "Compact boundary cofactor")
    close("B004", "sec:pr2_boundary_ledger_electroweak_lift", alpha_inv, 137.036361812007, 1e-12, "PR boundary alpha inverse")
    close("B005", "sec:pr2_boundary_ledger_electroweak_lift", rG, 0.073056757459128, 1e-12, "Generation suppression ratio")
    close("B006", "sec:pr2_weak_mixing_boundary_closure", Delta, 0.018644236701811, 1e-12, "Normalized weak boundary deficit")
    close("B007", "sec:pr2_weak_mixing_boundary_closure", sin2, 0.231355763298189, 1e-12, "Weak mixing sin^2")
    close("B008", "sec:pr2_weak_mixing_boundary_closure", cos2, 0.768644236701811, 1e-12, "Weak mixing cos^2")
    close("B009", "sec:pr2_weak_mixing_boundary_closure", tanW, 0.548627374785032, 1e-12, "g'/g = tan theta_W")
    close("B010", "sec:pr2_dimensionless_weak_order_factor", Xi, 2.0099841245909515, 1e-12, "Dimensionless weak-order factor")
    close("B011", "sec:pr2_dimensionless_weak_order_factor", math.sqrt(Xi), 1.417739089039641, 1e-12, "sqrt Xi")
    close("B012", "sec:pr2_terminal_weak_displacement_overlap", yT, 0.997513275401799, 1e-12, "Terminal weak overlap")
    close("B013", "sec:pr2_compact_spectral_hierarchy_action", Sbase, 37.18004007116382, 1e-12, "Base hierarchy action")
    close("B014", "sec:pr2_compact_spectral_hierarchy_action", dS, -5.892040980909848e-4, 1e-12, "Second-order action correction")
    close("B015", "sec:pr2_compact_spectral_hierarchy_action", Stotal, 37.17945086706573, 1e-12, "Total hierarchy action")
    close("B016", "sec:pr2_compact_spectral_hierarchy_action", LambdaEW, 173.67059834472832, 1e-10, "Weak displacement anchor")
    close("B017", "sec:pr2_generated_weak_scale_fermi_constant", vEW, 246.21959589022453, 1e-10, "Generated electroweak vacuum scale")
    close("B018", "sec:pr2_generated_weak_scale_fermi_constant", GF, 1.166379220175995e-5, 1e-16, "Generated Fermi constant")
    close("B019", "sec:pr2_generated_weak_scale_fermi_constant", (vEW - vRef) / vRef, -2.23e-7, 1e-9, "Weak-scale diagnostic residual")
    close("B020", "sec:pr2_generated_weak_scale_fermi_constant", (GF - GFRef) / GFRef, 4.46e-7, 1e-9, "Fermi diagnostic residual")
    alpha_inv_mz = 127.955
    e_mz = math.sqrt(4 * math.pi / alpha_inv_mz)
    g_mz = e_mz / math.sqrt(sin2)
    gp_mz = e_mz / math.sqrt(cos2)
    MWdiag = g_mz * vEW / 2
    MZdiag = math.sqrt(g_mz * g_mz + gp_mz * gp_mz) * vEW / 2
    close("B021", "sec:pr2_mass_geometry_diagnostic_coupling", MWdiag, 80.210045, 1e-6, "Diagnostic W mass using alpha(MZ)^-1")
    close("B022", "sec:pr2_mass_geometry_diagnostic_coupling", MZdiag, 91.488408, 1e-6, "Diagnostic Z mass using alpha(MZ)^-1")

    # Anomalies and charges.
    close("A001", "sec:pr2_residual_em_charges_fermion_ledger", 1 / 2 + (1 / 3) / 2, 2 / 3, 1e-15, "u_L charge")
    close("A002", "sec:pr2_residual_em_charges_fermion_ledger", -1 / 2 + (1 / 3) / 2, -1 / 3, 1e-15, "d_L charge")
    close("A003", "sec:pr2_residual_em_charges_fermion_ledger", 1 / 2 + (-1) / 2, 0, 1e-15, "nu_L charge")
    close("A004", "sec:pr2_residual_em_charges_fermion_ledger", -1 / 2 + (-1) / 2, -1, 1e-15, "e_L charge")
    exact("A005", "sec:pr2_pure_color_anomaly", 2 - 1 - 1, 0, "Pure color anomaly")
    close("A006", "sec:pr2_mixed_color_hypercharge_anomaly", 2 * 0.5 * (1 / 3) + 0.5 * (-4 / 3) + 0.5 * (2 / 3), 0, 1e-15, "Mixed color-hypercharge anomaly")
    close("A007", "sec:pr2_mixed_weak_hypercharge_anomaly", 3 * 0.5 * (1 / 3) + 0.5 * (-1), 0, 1e-15, "Mixed weak-hypercharge anomaly")
    close("A008", "sec:pr2_mixed_gravitational_hypercharge_anomaly", 6 * (1 / 3) + 3 * (-4 / 3) + 3 * (2 / 3) + 2 * (-1) + 2, 0, 1e-15, "Mixed gravitational-hypercharge anomaly")
    close("A009", "sec:pr2_cubic_hypercharge_anomaly", 6 * (1 / 3) ** 3 + 3 * (-4 / 3) ** 3 + 3 * (2 / 3) ** 3 + 2 * (-1) ** 3 + 2**3, 0, 1e-14, "Cubic hypercharge anomaly")
    truth("A010", "sec:pr2_witten_global_anomaly", 4 % 2 == 0, "One-generation Witten parity")
    truth("A011", "sec:pr2_three_sheet_representation_ledger", 12 % 2 == 0, "Three-generation Witten parity")

    # Flavor sheets.
    Ngen = (3 + 1) - 1
    eta1, eta2, eta3 = rG**2, rG, 1
    y1, y2, y3 = yT * eta1, yT * eta2, yT
    ratio = q_bc / c_bc
    exact("F001", "sec:pr2_generation_origin_flavor_sheets", Ngen, 3, "Generation count from compact quotient")
    close("F002", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta1, 0.005337289810442, 1e-12, "First sheet eta")
    close("F003", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta2, 0.073056757459128, 1e-12, "Second sheet eta")
    close("F004", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta3, 1, 1e-12, "Third sheet eta")
    truth("F005", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta1 < eta2 < eta3, "Sheet hierarchy ordering")
    close("F006", "sec:pr2_generation_sheet_overlap_hierarchy_main", ratio, 13.6879877341867, 1e-10, "Successive hierarchy ratio")
    close("F007", "sec:pr2_generation_sheet_overlap_hierarchy_main", y1, 0.005324017440582, 1e-12, "First terminal matter overlap")
    close("F008", "sec:pr2_generation_sheet_overlap_hierarchy_main", y2, 0.072875085423290, 1e-12, "Second terminal matter overlap")
    close("F009", "sec:pr2_generation_sheet_overlap_hierarchy_main", y3, 0.997513275401799, 1e-12, "Third terminal matter overlap")
    kappal, kappau, kappad, kappanu = 1 + rG * 2, 1 + rG * 23 / 9, 1 + rG * 20 / 9, 1 + rG
    Dl = [kappal * y1, kappal * y2, kappal * y3]
    Du = [kappau * y1, kappau * y2, kappau * y3]
    Dd = [kappad * y1, kappad * y2, kappad * y3]
    close("F010", "sec:pr2_sector_specific_compact_charge_norms", kappal, 1.146113514918256, 1e-12, "Charged-lepton sector factor")
    close("F011", "sec:pr2_sector_specific_compact_charge_norms", kappau, 1.186700602395549, 1e-12, "Up-quark sector factor")
    close("F012", "sec:pr2_sector_specific_compact_charge_norms", kappad, 1.162348349909173, 1e-12, "Down-quark sector factor")
    close("F013", "sec:pr2_sector_specific_compact_charge_norms", kappanu, 1.073056757459128, 1e-12, "Dirac-neutrino sector factor")
    close("F014", "sec:pr2_sector_specific_overlap_spectra", Dl[0], 0.006101928, 1e-9, "D_l first entry")
    close("F015", "sec:pr2_sector_specific_overlap_spectra", Dl[1], 0.083523120, 1e-9, "D_l second entry")
    close("F016", "sec:pr2_sector_specific_overlap_spectra", Dl[2], 1.143263446, 1e-9, "D_l third entry")
    close("F017", "sec:pr2_sector_specific_overlap_spectra", Du[2] / Dd[2], 1.02095090726311, 1e-12, "Up/down sheetwise sector ratio")
    close("F018", "sec:pr2_hypercharge_neutral_order_terms", -(-1) + 1 + (-2), 0, 1e-15, "Charged-lepton hypercharge neutrality")
    close("F019", "sec:pr2_hypercharge_neutral_order_terms", -(1 / 3) + 1 + (-2 / 3), 0, 1e-15, "Down-quark hypercharge neutrality")
    close("F020", "sec:pr2_hypercharge_neutral_order_terms", -(1 / 3) - 1 + (4 / 3), 0, 1e-15, "Up-quark hypercharge neutrality")
    close("F021", "sec:pr2_hypercharge_neutral_order_terms", -(-1) - 1 + 0, 0, 1e-15, "Dirac-neutrino hypercharge neutrality")

    # Charged leptons.
    thetaK = 2 / Ngen**2
    k0 = (1 + math.sqrt(2) * math.cos(thetaK + 2 * math.pi * 0 / 3)) ** 2
    k1 = (1 + math.sqrt(2) * math.cos(thetaK + 2 * math.pi * 1 / 3)) ** 2
    k2 = (1 + math.sqrt(2) * math.cos(thetaK + 2 * math.pi * 2 / 3)) ** 2
    MlMeV = 1000 * LambdaEW * rG * Delta * (4 / 3) * C1 * C2
    mtau, me, mmu = MlMeV * k0, MlMeV * k1, MlMeV * k2
    koide = (me + mmu + mtau) / (math.sqrt(me) + math.sqrt(mmu) + math.sqrt(mtau)) ** 2
    close("L001", "sec:pr2_three_sheet_square_root_flavor_geometry", thetaK, 2 / 9, 1e-12, "Koide sheet phase")
    close("L002", "sec:pr2_koide_identity_three_sheet_geometry", math.cos(thetaK) + math.cos(thetaK + 2 * math.pi / 3) + math.cos(thetaK + 4 * math.pi / 3), 0, 1e-12, "Three-sheet cosine sum")
    close("L003", "sec:pr2_koide_identity_three_sheet_geometry", math.cos(thetaK) ** 2 + math.cos(thetaK + 2 * math.pi / 3) ** 2 + math.cos(thetaK + 4 * math.pi / 3) ** 2, 1.5, 1e-12, "Three-sheet cosine-square sum")
    close("L004", "sec:pr2_charged_lepton_compact_scale", C1, 0.996286606565180, 1e-12, "Charged-lepton C1")
    close("L005", "sec:pr2_charged_lepton_compact_scale", C2, 0.998776379293597, 1e-12, "Charged-lepton C2")
    close("L006", "sec:pr2_charged_lepton_compact_scale", MlMeV, 313.850332183, 1e-9, "Charged-lepton compact scale in MeV")
    close("L007", "sec:pr2_generated_charged_lepton_masses", me, 0.510984463, 1e-9, "Electron mass candidate")
    close("L008", "sec:pr2_generated_charged_lepton_masses", mmu, 105.656418843, 1e-9, "Muon mass candidate")
    close("L009", "sec:pr2_generated_charged_lepton_masses", mtau, 1776.934589789, 1e-9, "Tau mass candidate")
    close("L010", "sec:pr2_koide_identity_three_sheet_geometry", koide, 2 / 3, 1e-12, "Koide ratio")
    close("L011", "sec:pr2_generated_charged_lepton_masses", (me - 0.510998950) / 0.510998950 * 1e6, -28.35, 1e-2, "Electron ppm residual")
    close("L012", "sec:pr2_generated_charged_lepton_masses", (mmu - 105.6583755) / 105.6583755 * 1e6, -18.52, 1e-2, "Muon ppm residual")
    close("L013", "sec:pr2_generated_charged_lepton_masses", (mtau - 1776.930) / 1776.930 * 1e6, 2.58, 1e-2, "Tau ppm residual")

    # QCD/quarks.
    alpha3 = 1 / (q_bc * c_bc - (1 - c_bc))
    mut = LambdaEW * C1 * C2
    mub = LambdaEW * (rG / 3) * (1 - Delta * c_bc)
    muc = LambdaEW * rG**2 * (4 / 3) * (1 + Delta * AEW)
    close("Q001", "sec:pr2_compact_boundary_strong_coupling_candidate", alpha3, 0.117861507469150, 1e-12, "Compact strong-coupling candidate")
    close("Q002", "sec:pr2_pr_derived_heavy_quark_thresholds", mut, 172.8139732666624, 1e-10, "Top threshold candidate")
    close("Q003", "sec:pr2_pr_derived_heavy_quark_thresholds", mub, 4.1664504826753515, 1e-12, "Bottom threshold candidate")
    close("Q004", "sec:pr2_pr_derived_heavy_quark_thresholds", muc, 1.274964814257465, 1e-12, "Charm threshold candidate")
    truth("Q005", "sec:pr2_pr_derived_heavy_quark_thresholds", mut > mub > muc > 0, "Heavy-threshold ordering")
    exact("Q006", "sec:pr2_qcd_running_ledger_main", 11 - 2 * 3 // 3, 9, "beta0 for nf=3")
    close("Q007", "sec:pr2_qcd_running_ledger_main", 11 - 2 * 4 / 3, 25 / 3, 1e-15, "beta0 for nf=4")
    close("Q008", "sec:pr2_qcd_running_ledger_main", 11 - 2 * 5 / 3, 23 / 3, 1e-15, "beta0 for nf=5")
    exact("Q009", "sec:pr2_qcd_running_ledger_main", 11 - 2 * 6 // 3, 7, "beta0 for nf=6")
    close("Q010", "sec:pr2_qcd_running_ledger_main", 12 / (33 - 2 * 5), 12 / 23, 1e-15, "Mass-running exponent for nf=5")
    L5 = solve_lambda_3loop(MZdiag, alpha3, 5)
    L6 = solve_lambda_3loop(mut, alpha_3loop(mut, L5, 5), 6)
    L4 = solve_lambda_3loop(mub, alpha_3loop(mub, L5, 5), 4)
    L3 = solve_lambda_3loop(muc, alpha_3loop(muc, L4, 4), 3)
    bMZ = mass_run_1loop(mub, mub, MZdiag, 5, L5)
    cAtb = mass_run_1loop(muc, muc, mub, 4, L4)
    cMZ = mass_run_1loop(cAtb, mub, MZdiag, 5, L5)
    close("Q011", "sec:pr2_qcd_threshold_ledger", L6, 0.08776758507426047, 1e-12, "Lambda_6 from three-loop matching")
    close("Q012", "sec:pr2_qcd_threshold_ledger", L5, 0.2074330873004123, 1e-12, "Lambda_5 from alpha_3 at MZ")
    close("Q013", "sec:pr2_qcd_threshold_ledger", L4, 0.2861117918030313, 1e-12, "Lambda_4 from bottom matching")
    close("Q014", "sec:pr2_qcd_threshold_ledger", L3, 0.3246524964107782, 1e-12, "Lambda_3 from charm matching")
    close("Q015", "sec:pr2_qcd_threshold_ledger", alpha_3loop(mut, L6, 6) - alpha_3loop(mut, L5, 5), 0, 1e-12, "Top-threshold coupling continuity")
    close("Q016", "sec:pr2_qcd_threshold_ledger", alpha_3loop(mub, L4, 4) - alpha_3loop(mub, L5, 5), 0, 1e-12, "Bottom-threshold coupling continuity")
    close("Q017", "sec:pr2_qcd_threshold_ledger", alpha_3loop(muc, L3, 3) - alpha_3loop(muc, L4, 4), 0, 1e-12, "Charm-threshold coupling continuity")
    close("Q018", "sec:pr2_qcd_threshold_ledger", bMZ, 2.9807846581959314, 1e-12, "b running diagnostic at MZ")
    close("Q019", "sec:pr2_qcd_threshold_ledger", cAtb, 0.9892172861698667, 1e-12, "c running diagnostic at bottom threshold")
    close("Q020", "sec:pr2_qcd_threshold_ledger", cMZ, 0.7077112094571149, 1e-12, "c running diagnostic at MZ")
    close("Q021", "sec:pr2_light_sector_confinement_average_main", Cconf, 0.8983422324239495, 1e-12, "Compact confinement average")
    close("Q022", "sec:pr2_light_sector_confinement_average_main", 2 * Cconf - 1, c_bc, 1e-12, "Confinement endpoint reconstructs c_bc")
    ms = 1000 * mub * (rG / 3) * (1 + Delta * AEW) * Cconf
    md = ms * rG * c_bc * (1 - AEW * Delta) * Cconf
    mu = md * ((1 + c_bc) / 4) * (1 + Delta * c_bc / 4)
    close("Q023", "sec:pr2_light_quark_hierarchy_candidate", ms, 94.028510538, 1e-9, "Strange-quark low-energy candidate")
    close("Q024", "sec:pr2_light_quark_hierarchy_candidate", md, 4.761039493, 1e-9, "Down-quark low-energy candidate")
    close("Q025", "sec:pr2_light_quark_hierarchy_candidate", mu, 2.146462595, 1e-9, "Up-quark low-energy candidate")
    truth("Q026", "sec:pr2_six_quark_hierarchy_candidate", mu < md < ms and ms / 1000 < muc < mub < mut, "Six-quark hierarchy ordering")

    # CKM/PMNS.
    lambdaPR = math.sqrt(rG * c_bc * Cconf * (1 - AEW * Delta))
    ACKM = c_bc / (1 - AEW * Delta)
    Rb = (1 - rG) * c_bc / (1 + c_bc) * (1 - AEW * Delta)
    deltaCKM = math.pi / 3 + math.sqrt(Delta)
    s12, s23, s13 = lambdaPR, ACKM * lambdaPR**2, ACKM * lambdaPR**3 * Rb
    Vckm = ckm_matrix(s12, s23, s13, deltaCKM)
    VckmExpected = [[0.974347364, 0.225018430, 0.003730932], [0.224881887, 0.973495229, 0.041655455], [0.008680487, 0.040911440, 0.999125069]]
    close("M001", "sec:pr2_ckm_compact_mixing_candidate", lambdaPR, 0.225019996525935, 1e-12, "Compact Cabibbo sheet angle")
    close("M002", "sec:pr2_ckm_compact_mixing_candidate", ACKM, 0.822683296413403, 1e-12, "Compact CKM hierarchy coefficient")
    close("M003", "sec:pr2_ckm_compact_mixing_candidate", Rb, 0.398035078485258, 1e-12, "Compact unitarity-apex radius")
    close("M004", "sec:pr2_ckm_compact_mixing_candidate", deltaCKM, 1.1837414514697735, 1e-12, "CKM phase in radians")
    close("M005", "sec:pr2_ckm_compact_mixing_candidate", s23, 0.041655745073430, 1e-12, "CKM s23")
    close("M006", "sec:pr2_ckm_compact_mixing_candidate", s13, 0.003730932297278, 1e-12, "CKM s13")
    matclose("M007", "sec:pr2_ckm_compact_mixing_candidate", abs_matrix(Vckm), VckmExpected, 1e-9, "CKM absolute matrix")
    matclose("M008", "sec:pr2_ckm_compact_mixing_candidate", matmul(dagger(Vckm), Vckm), ident(3), 1e-14, "CKM unitarity")
    close("M009", "sec:pr2_ckm_compact_mixing_candidate", jarlskog(s12, s23, s13, deltaCKM), 3.152605677e-5, 1e-13, "CKM Jarlskog invariant")
    pmns12 = Cconf / Ngen
    pmns23 = AEW / Ngen
    pmns13 = Delta * (1 + rG) / Cconf
    theta12 = math.degrees(math.asin(math.sqrt(pmns12)))
    theta23 = math.degrees(math.asin(math.sqrt(pmns23)))
    theta13 = math.degrees(math.asin(math.sqrt(pmns13)))
    deltaCP = math.pi + 2 * math.sqrt(Delta)
    Upmns = ckm_matrix(math.sqrt(pmns12), math.sqrt(pmns23), math.sqrt(pmns13), deltaCP)
    UpmnsExpected = [[0.827618, 0.541090, 0.149232], [0.271685, 0.611360, 0.743254], [0.491158, 0.577460, 0.652153]]
    close("M010", "sec:pr2_pmns_compact_lepton_mixing_candidate", pmns12, 0.299447410807983, 1e-12, "PMNS solar sin^2")
    close("M011", "sec:pr2_pmns_compact_lepton_mixing_candidate", theta12, 33.176356643, 1e-9, "PMNS solar angle")
    close("M012", "sec:pr2_pmns_compact_lepton_mixing_candidate", pmns23, 0.565008899090616, 1e-12, "PMNS atmospheric sin^2")
    close("M013", "sec:pr2_pmns_compact_lepton_mixing_candidate", theta23, 48.735310403, 1e-9, "PMNS atmospheric angle")
    close("M014", "sec:pr2_pmns_compact_lepton_mixing_candidate", pmns13, 0.022270270124743, 1e-12, "PMNS reactor sin^2")
    close("M015", "sec:pr2_pmns_compact_lepton_mixing_candidate", theta13, 8.582438059, 1e-9, "PMNS reactor angle")
    close("M016", "sec:pr2_pmns_compact_lepton_mixing_candidate", deltaCP, 3.414680454, 1e-9, "PMNS CP phase")
    matclose("M017", "sec:pr2_pmns_compact_lepton_mixing_candidate", abs_matrix(Upmns), UpmnsExpected, 1e-6, "PMNS absolute matrix")
    matclose("M018", "sec:pr2_pmns_compact_lepton_mixing_candidate", matmul(dagger(Upmns), Upmns), ident(3), 1e-14, "PMNS unitarity")
    close("M019", "sec:pr2_pmns_compact_lepton_mixing_candidate", jarlskog(math.sqrt(pmns12), math.sqrt(pmns23), math.sqrt(pmns13), deltaCP), -8.935540e-3, 1e-9, "PMNS Jarlskog invariant")

    # Neutrinos.
    Cnu = 1 - Delta * c_bc
    R21 = Delta * ((1 + c_bc) ** 2 / 2) * Cnu
    m1 = 0
    m3 = (vEW**2 / Mpl) * 1e9 * rG ** (-3) * c_bc * Cnu
    m2 = math.sqrt(R21) * m3
    dm21 = m2**2 - m1**2
    dm31 = m3**2 - m1**2
    sumNu = m1 + m2 + m3
    mbeta = math.sqrt((1 - pmns13) * pmns12 * m2**2 + pmns13 * m3**2)
    ynuDirac = math.sqrt(2) * m3 / (vEW * 1e9)
    phiM = math.pi * Cconf
    alpha31 = (phiM + 2 * deltaCP) % (2 * math.pi)
    mbb = abs(m2 * (1 - pmns13) * pmns12 + m3 * pmns13 * cmath.exp(1j * phiM))
    close("N001", "sec:pr2_neutrino_normal_ordering_singlet_channel", Cnu, 0.985147, 1e-6, "Compact neutrino loss factor")
    close("N002", "sec:pr2_neutrino_normal_ordering_singlet_channel", R21, 2.964551668e-2, 1e-11, "Solar-to-atmospheric splitting ratio")
    close("N003", "sec:pr2_generated_neutrino_spectrum", m1, 0, 1e-12, "Massless residual compact-singlet sheet")
    close("N004", "sec:pr2_generated_neutrino_spectrum", m2, 8.627283010e-3, 1e-12, "Second neutrino mass")
    close("N005", "sec:pr2_generated_neutrino_spectrum", m3, 5.010655367e-2, 2e-12, "Third neutrino mass")
    truth("N006", "sec:pr2_generated_neutrino_spectrum", m1 < m2 < m3, "Normal-ordering hierarchy")
    close("N007", "sec:pr2_generated_neutrino_spectrum", dm21, 7.443001214e-5, 1e-13, "Solar mass-squared splitting")
    close("N008", "sec:pr2_generated_neutrino_spectrum", dm31, 2.510666721e-3, 1e-12, "Atmospheric mass-squared splitting")
    close("N009", "sec:pr2_generated_neutrino_spectrum", dm21 / dm31, 2.964551668e-2, 1e-11, "Splitting ratio")
    close("N010", "sec:pr2_generated_neutrino_spectrum", sumNu, 5.873383668e-2, 1e-12, "Cosmological neutrino mass sum")
    close("N011", "sec:pr2_generated_neutrino_spectrum", mbeta, 8.815029410e-3, 1e-12, "Beta-decay effective mass")
    close("N012", "sec:pr2_majorana_dominant_compact_singlet_projection", ynuDirac, 2.88e-13, 1e-15, "Equivalent Dirac Yukawa diagnostic")
    close("N013", "sec:pr2_majorana_phase_boundary", phiM, 2.822225357793, 1e-12, "Majorana interference phase")
    close("N014", "sec:pr2_majorana_phase_boundary", alpha31, 3.368400958885, 1e-12, "Locked alpha31 phase")
    close("N015", "sec:pr2_majorana_phase_boundary", mbb, 1.507694477e-3, 1e-12, "Neutrinoless double-beta effective mass")
    mass_phases = [m1, m2, m3 * cmath.exp(1j * alpha31)]
    Mnu = [
        [sum(Upmns[i][k].conjugate() * mass_phases[k] * Upmns[j][k].conjugate() for k in range(3)) for j in range(3)]
        for i in range(3)
    ]
    matclose("N016", "sec:pr2_flavor_basis_majorana_mass_matrix", transpose(Mnu), Mnu, 1e-14, "Flavor-basis Majorana matrix is symmetric")


def write_reports():
    REPORTS.mkdir(exist_ok=True)
    failed = [r for r in results if r["status"] == "FAIL"]
    passed = len(results) - len(failed)

    with (REPORTS / "pr2_reference_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "section", "kind", "status", "actual", "expected", "error", "tolerance", "note"])
        writer.writeheader()
        writer.writerows(results)

    with (REPORTS / "pr2_reference_traceability.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "section", "status", "note"])
        writer.writeheader()
        for r in results:
            writer.writerow({k: r[k] for k in ["id", "section", "status", "note"]})

    lines = [
        "# PR-II Reference Test Summary",
        "",
        "Execution engine: bundled Python reference runner",
        "",
        f"- Total tests: {len(results)}",
        f"- Passed: {passed}",
        f"- Failed: {len(failed)}",
        "",
        "This independent Python runner mirrors the 155 core numerical checks; the Maple run remains the canonical symbolic audit.",
        "",
        "## Failed Tests",
        "",
    ]
    if failed:
        for r in failed:
            lines.append(f"- `{r['id']}` ({r['section']}): {r['note']} | error={r['error']} tolerance={r['tolerance']}")
    else:
        lines.append("No failures.")
    (REPORTS / "pr2_reference_summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    scope = """# PR-II Reference Runner Scope

- The Python runner independently recomputes 155 core numerical checks.
- The Maple run is the canonical symbolic audit and includes the full manuscript display inventory.
- The QCD Lambda ledger uses the standard three-loop alpha_s expression with threshold continuity, matching the manuscript's tabulated values and running diagnostics.
"""
    (REPORTS / "pr2_reference_scope.md").write_text(scope, encoding="utf-8")


if __name__ == "__main__":
    run()
    write_reports()
    failures = sum(1 for r in results if r["status"] == "FAIL")
    print(f"Reference runner complete: {len(results)} tests, {failures} failed.")
