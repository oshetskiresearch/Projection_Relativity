restart:
# Start Maple in the extracted package directory. If needed, set the directory
# explicitly with: currentdir("C:/path/to/pr2_symbolic_tester_code_package"):
read "ProjectionRelativityIIAppendixVerify.mpl":
PR2_RunAll();
