with(LinearAlgebra):
with(StringTools):

results := table():
result_count := 0:
proof_rows := []:
selftest_rows := []:
selftest_count := 0:
derivation_rows := []:
boundary_rows := []:
current_print_section := "":

PR2_source_repo := "oshetskiresearch/Projection_Relativity":
PR2_source_branch := "main":
PR2_source_file := "Oshetski_Projection_Relativity_II_Main.tex":
PR2_source_path := cat("source/", PR2_source_file):
PR2_source_label := cat("source:", PR2_source_file):

ToFlatString := proc(x)
    local s;
    try
        s := convert(evalf(x, 18), string);
    catch:
        try
            s := convert(x, string);
        catch:
            s := "unprintable";
        end try;
    end try;
    s := SubstituteAll(s, "\n", " ");
    s := SubstituteAll(s, "\r", " ");
    return s;
end proc:

Csv := proc(x)
    local s;
    s := ToFlatString(x);
    s := SubstituteAll(s, "\"", "\"\"");
    return cat("\"", s, "\"");
end proc:

ResetPR2HarnessState := proc()
    global results, result_count, proof_rows, selftest_rows, selftest_count,
           derivation_rows, boundary_rows, current_print_section;
    results := table();
    result_count := 0;
    proof_rows := [];
    selftest_rows := [];
    selftest_count := 0;
    derivation_rows := [];
    boundary_rows := [];
    current_print_section := "";
end proc:

AddResult := proc(id, section, kind, status, actual, expected, err, tol, note)
    global results, result_count, proof_rows, current_print_section;
    result_count := result_count + 1;
    results[result_count] := table();
    results[result_count]["id"] := id;
    results[result_count]["section"] := section;
    results[result_count]["kind"] := kind;
    results[result_count]["status"] := status;
    results[result_count]["actual"] := ToFlatString(actual);
    results[result_count]["expected"] := ToFlatString(expected);
    results[result_count]["error"] := ToFlatString(err);
    results[result_count]["tolerance"] := ToFlatString(tol);
    results[result_count]["note"] := note;
    if status = "PASS" then
        proof_rows := [op(proof_rows),
            [id, section, kind, note, ToFlatString(actual), ToFlatString(expected),
             ToFlatString(err), ToFlatString(tol), status]];
    end if;
    if section <> current_print_section then
        current_print_section := section;
        printf("\n=== %s ===\n", section);
    end if;
    printf("%s: %s - %s\n", status, id, note);
    if kind = "numeric" then
        printf("      got = %a, expected = %a, abs error = %a, tol = %a\n",
               evalf(actual, 16), evalf(expected, 16), evalf(err, 6), tol);
    elif kind = "matrix" or kind = "vector" then
        printf("      max abs residual = %a, tol = %a\n", evalf(err, 6), tol);
    end if;
end proc:

CountFailures := proc()
    global results, result_count;
    local i, n;
    n := 0;
    for i to result_count do
        if results[i]["status"] = "FAIL" then
            n := n + 1;
        end if;
    end do;
    return n;
end proc:

MaxAbsMatrix := proc(A)
    local i, j, err;
    err := 0;
    for i to RowDimension(A) do
        for j to ColumnDimension(A) do
            err := max(err, abs(evalf(A[i,j])));
        end do;
    end do;
    return err;
end proc:

MaxAbsVectorDiff := proc(A, B)
    local i, err;
    err := 0;
    for i to Dimension(A) do
        err := max(err, abs(evalf(A[i] - B[i])));
    end do;
    return err;
end proc:

AssertClose := proc(id, section, actual, expected, tol, note)
    local err, status;
    err := abs(evalf(actual - expected));
    if evalb(err <= tol) then status := "PASS"; else status := "FAIL"; end if;
    AddResult(id, section, "numeric", status, actual, expected, err, tol, note);
end proc:

AssertExact := proc(id, section, actual, expected, note)
    local err, status;
    err := simplify(actual - expected);
    if evalb(err = 0) then status := "PASS"; else status := "FAIL"; end if;
    AddResult(id, section, "exact", status, actual, expected, err, 0, note);
end proc:

AssertTrue := proc(id, section, condition, note)
    local status;
    if evalb(condition) then status := "PASS"; else status := "FAIL"; end if;
    AddResult(id, section, "predicate", status, condition, true, 0, 0, note);
end proc:

AssertMatrixClose := proc(id, section, actual, expected, tol, note)
    local err, status;
    err := MaxAbsMatrix(actual - expected);
    if evalb(err <= tol) then status := "PASS"; else status := "FAIL"; end if;
    AddResult(id, section, "matrix", status, actual, expected, err, tol, note);
end proc:

AssertVectorClose := proc(id, section, actual, expected, tol, note)
    local err, status;
    err := MaxAbsVectorDiff(actual, expected);
    if evalb(err <= tol) then status := "PASS"; else status := "FAIL"; end if;
    AddResult(id, section, "vector", status, actual, expected, err, tol, note);
end proc:

AssertTextContains := proc(id, section, text, needle, note)
    local pos, status;
    pos := Search(needle, text);
    if evalb(pos <> 0) then status := "PASS"; else status := "FAIL"; end if;
    AddResult(id, section, "source-text", status, pos, needle, 0, 0, note);
end proc:

ReadTextFileIfExists := proc(path)
    local text;
    if FileTools:-Exists(path) then
        try
            text := FileTools:-Text:-ReadFile(path);
            return [true, path, text];
        catch:
            return [false, path, ""];
        end try;
    end if;
    return [false, path, ""];
end proc:

AbsMatrix := proc(A)
    local i, j, B;
    B := Matrix(RowDimension(A), ColumnDimension(A));
    for i to RowDimension(A) do
        for j to ColumnDimension(A) do
            B[i,j] := abs(evalf(A[i,j]));
        end do;
    end do;
    return B;
end proc:

Alpha3Loop := proc(mu, Lambda, nf)
    local beta0, beta1, beta2, L, term1, term2, term3;
    beta0 := 11 - 2*nf/3;
    beta1 := 102 - 38*nf/3;
    beta2 := 2857/2 - 5033*nf/18 + 325*nf^2/54;
    L := ln(mu^2/Lambda^2);
    term1 := 4*Pi/(beta0*L);
    term2 := 1 - (beta1/beta0^2)*ln(L)/L;
    term3 := ((beta1^2)*(ln(L)^2 - ln(L) - 1) + beta0*beta2)/(beta0^4*L^2);
    return evalf(term1*(term2 + term3));
end proc:

SolveLambda3Loop := proc(mu, alpha_target, nf)
    local lo, hi, mid, k, val;
    lo := 10^(-12);
    hi := 0.999999*mu;
    for k to 250 do
        mid := (lo + hi)/2;
        val := Alpha3Loop(mu, mid, nf);
        if evalb(val < alpha_target) then
            lo := mid;
        else
            hi := mid;
        end if;
    end do;
    return evalf((lo + hi)/2);
end proc:

MassRun1Loop := proc(m1, mu1, mu2, nf, Lambda)
    local a_m;
    a_m := 12/(33 - 2*nf);
    return evalf(m1*(Alpha3Loop(mu2, Lambda, nf)/Alpha3Loop(mu1, Lambda, nf))^a_m);
end proc:

CKMMatrix := proc(s12, s23, s13, delta)
    local c12, c23, c13;
    c12 := sqrt(1 - s12^2);
    c23 := sqrt(1 - s23^2);
    c13 := sqrt(1 - s13^2);
    return Matrix([
        [c12*c13, s12*c13, s13*exp(-I*delta)],
        [-s12*c23 - c12*s23*s13*exp(I*delta),
         c12*c23 - s12*s23*s13*exp(I*delta),
         s23*c13],
        [s12*s23 - c12*c23*s13*exp(I*delta),
         -c12*s23 - s12*c23*s13*exp(I*delta),
         c23*c13]
    ]);
end proc:

Jarlskog := proc(s12, s23, s13, delta)
    local c12, c23, c13;
    c12 := sqrt(1 - s12^2);
    c23 := sqrt(1 - s23^2);
    c13 := sqrt(1 - s13^2);
    return evalf(s12*s23*s13*c12*c23*c13^2*sin(delta));
end proc:

PR2_RecordBoundary := proc(kind, label, detail)
    global boundary_rows;
    boundary_rows := [op(boundary_rows), [kind, label, detail]];
    printf("%s: %s\n", kind, label);
    printf("      %s\n", detail);
end proc:

PR2_note := proc(label, detail)
    PR2_RecordBoundary("NOTE", label, detail);
end proc:

PR2_data := proc(label, detail)
    PR2_RecordBoundary("DATA", label, detail);
end proc:

PR2_assumption := proc(label, detail)
    PR2_RecordBoundary("ASSUMPTION", label, detail);
end proc:

PR2_manuscript := proc(label, detail)
    PR2_RecordBoundary("MANUSCRIPT", label, detail);
end proc:

PR2_CountBoundary := proc(kind)
    global boundary_rows;
    local i, n;
    n := 0;
    for i to nops(boundary_rows) do
        if boundary_rows[i][1] = kind then
            n := n + 1;
        end if;
    end do;
    return n;
end proc:

PR2_SelfAssert := proc(label, condition)
    global selftest_rows, selftest_count;
    if evalb(condition) then
        selftest_count := selftest_count + 1;
        selftest_rows := [op(selftest_rows), [label, "PASS"]];
        printf("SELFTEST PASS: %s\n", label);
    else
        selftest_rows := [op(selftest_rows), [label, "FAIL"]];
        error "Harness self-test failed: %1", label;
    end if;
end proc:

PR2_SelfRejectClose := proc(label, got, wrong_expected, tol)
    local err;
    err := abs(evalf(got - wrong_expected));
    PR2_SelfAssert(label, evalb(err > tol));
end proc:

PR2_SelfRejectEqual := proc(label, got, wrong_expected)
    local delta;
    delta := simplify(got - wrong_expected);
    PR2_SelfAssert(label, not evalb(delta = 0));
end proc:

PR2_SelfRejectMatrixEqual := proc(label, A, B)
    local C, i, j, different;
    C := A - B;
    different := false;
    for i to RowDimension(C) do
        for j to ColumnDimension(C) do
            if not evalb(simplify(C[i,j]) = 0) then
                different := true;
            end if;
        end do;
    end do;
    PR2_SelfAssert(label, different);
end proc:

PR2_HarnessSelfTest := proc()
    local q_bc, c_bc, rG, Delta, TY, sin2, Xi, yT, Mpl, Sbase,
          dS, Stotal, LambdaEW, vEW, wrongV, Ubad, Vgood,
          thetaWrong, koideWrong, Ml, k0, k1, k2, I3;

    printf("\n=== Harness Self-Validation: Negative Controls ===\n");
    q_bc := 10.905007182855176;
    c_bc := 3354902985/4211081216;
    rG := evalf(c_bc/q_bc);
    Delta := evalf((1 - c_bc)/q_bc);
    TY := 1/4;
    sin2 := evalf(TY - Delta);
    Xi := evalf(q_bc*c_bc*sin2);
    yT := evalf(sqrt(2/Xi));
    Mpl := 2.4353234593382036*10^18;
    Sbase := evalf(Pi*q_bc + ln(q_bc/c_bc) + ln(4/3) + (TY - sin2)*(1 + c_bc)/2);
    dS := evalf(-1/2*(1 + 3*c_bc)*Delta^2);
    Stotal := evalf(Sbase + dS);
    LambdaEW := evalf(Mpl*exp(-Stotal));
    vEW := evalf(LambdaEW*sqrt(Xi));

    PR2_SelfRejectClose("reject weak mixing without boundary deficit", sin2, 1/4, 10^(-12));
    PR2_SelfRejectClose("reject stale compact boundary cofactor", evalf(c_bc), 0.75, 10^(-12));
    PR2_SelfRejectClose("reject weak scale without second-order action correction",
                        evalf(Mpl*exp(-Sbase)*sqrt(Xi)), vEW, 10^(-8));
    PR2_SelfRejectClose("reject Fermi constant missing sqrt(2)",
                        evalf(1/vEW^2), evalf(1/(sqrt(2)*vEW^2)), 10^(-10));
    PR2_SelfRejectClose("reject inverted generation hierarchy",
                        evalf(yT*rG^2), yT, 10^(-6));

    thetaWrong := 1/3;
    Ml := 313.850332183;
    k0 := evalf((1 + sqrt(2)*cos(thetaWrong))^2);
    k1 := evalf((1 + sqrt(2)*cos(thetaWrong + 2*Pi/3))^2);
    k2 := evalf((1 + sqrt(2)*cos(thetaWrong + 4*Pi/3))^2);
    koideWrong := evalf((Ml*k0 + Ml*k1 + Ml*k2)/(sqrt(Ml*k0) + sqrt(Ml*k1) + sqrt(Ml*k2))^2);
    PR2_SelfRejectClose("reject wrong Koide phase by mass spectrum",
                        evalf(Ml*k1), 0.510984463, 10^(-6));

    Ubad := Matrix([[1,1,0],[0,1,0],[0,0,1]]);
    I3 := IdentityMatrix(3);
    PR2_SelfRejectMatrixEqual("reject non-unitary flavor rotation",
                              HermitianTranspose(Ubad).Ubad, I3);

    wrongV := vEW^2*10^9*rG^3*c_bc;
    PR2_SelfRejectClose("reject neutrino determinant suppression instead of lift",
                        wrongV, 5.010655367*10^(-2), 10^(-6));
end proc:

PR2_RecordDerivation := proc(paper_id, paper_location, maple_proc, label, start_expr, maple_step, result_expr)
    global derivation_rows;
    derivation_rows := [op(derivation_rows),
        [paper_id, paper_location, maple_proc, label, start_expr, maple_step, result_expr]];
end proc:

PR2_RecordCoreDerivations := proc()
    PR2_RecordDerivation("B007",
        "sec:pr2_weak_mixing_boundary_closure",
        "RunPR2Tests",
        "Weak mixing from boundary deficit",
        "sin2 = 1/4 - (1-c_bc)/q_bc",
        "Substitute PR-I q_bc and c_bc, then evalf.",
        "0.231355763298189");

    PR2_RecordDerivation("B017",
        "sec:pr2_generated_weak_scale_fermi_constant",
        "RunPR2Tests",
        "Weak scale from compact hierarchy action",
        "v_EW = Mbar_Pl exp(-S_total) sqrt(q_bc c_bc sin2)",
        "Build S_base, add second-order non-Abelian correction, exponentiate.",
        "246.21959589022453 GeV");

    PR2_RecordDerivation("A009",
        "sec:pr2_cubic_hypercharge_anomaly",
        "RunPR2Tests",
        "Cubic hypercharge anomaly cancellation",
        "6(1/3)^3 + 3(-4/3)^3 + 3(2/3)^3 + 2(-1)^3 + 2^3",
        "Simplify exact rational expression.",
        "0");

    PR2_RecordDerivation("L010",
        "sec:pr2_koide_identity_three_sheet_geometry",
        "RunPR2Tests",
        "Koide identity from three-sheet trigonometry",
        "sum m_a/(sum sqrt(m_a))^2 with k_a(theta)",
        "Use sum cos(theta+2pi a/3)=0 and sum cos^2(...)=3/2.",
        "2/3");

    PR2_RecordDerivation("Q011-Q020",
        "sec:pr2_qcd_threshold_ledger",
        "RunPR2Tests",
        "Three-loop QCD threshold ledger",
        "alpha_s^(nf)(mu,Lambda_nf)",
        "Invert three-loop running and impose alpha_s continuity at t, b, c thresholds.",
        "Lambda_6, Lambda_5, Lambda_4, Lambda_3 and running diagnostics");

    PR2_RecordDerivation("M008/M018",
        "sec:pr2_ckm_pmns_flavor_projection",
        "RunPR2Tests",
        "Flavor-matrix unitarity",
        "V = standard unitary parameterization(s12,s23,s13,delta)",
        "Compute HermitianTranspose(V).V - I and take max residual.",
        "CKM and PMNS residuals <= 1e-14");

    PR2_RecordDerivation("N015",
        "sec:pr2_majorana_phase_boundary",
        "RunPR2Tests",
        "Neutrinoless double-beta effective mass",
        "abs(m2 c13^2 s12^2 + m3 s13^2 exp(i phi_M))",
        "Use phi_M = pi C_conf and generated normal-ordering masses.",
        "1.507694477e-3 eV");
end proc:

PR2_BoundaryNotes := proc()
    PR2_note("Radiative electroweak precision layer deferred",
        "The harness verifies tree-level locking, rho, Fermi limit, and diagnostic W/Z values. Full Delta r and alpha(0)->alpha(MZ) running are PR-III obligations.");
    PR2_note("Scalar mass is a Hessian target, not a PR-II generated value",
        "The harness verifies scalar coupling ratios but does not assert a Higgs-mass prediction.");
    PR2_data("External experimental references are diagnostics only",
        "Observed lepton, quark, CKM, PMNS, and neutrino reference values are not used to generate the PR-II candidates.");
end proc:

PR2_SourceTextCoverageAudit := proc()
    global PR2_source_path, PR2_source_label;
    local source, ok, text;
    printf("\n=== Source-Text Coverage Audit ===\n");
    source := ReadTextFileIfExists(PR2_source_path);
    ok := source[1];
    text := source[3];
    if not ok then
        PR2_data("Source text coverage skipped",
            cat("Could not read ", PR2_source_path, ". Run fetch_github_source.ps1 or run_full_audit_windows.ps1 first."));
        return;
    end if;

    AssertTextContains("SRC001", PR2_source_label, text, "\\label{sec:pr2_weak_mixing_boundary_closure}", "Weak mixing section label present");
    AssertTextContains("SRC002", PR2_source_label, text, "0.231355763298189", "Weak mixing numeric target present");
    AssertTextContains("SRC003", PR2_source_label, text, "246.21959589022453", "Generated weak scale target present");
    AssertTextContains("SRC004", PR2_source_label, text, "1.166379220175995", "Fermi constant target present");
    AssertTextContains("SRC005", PR2_source_label, text, "\\label{sec:pr2_fermion_representation_anomaly_cancellation}", "Anomaly section label present");
    AssertTextContains("SRC006", PR2_source_label, text, "\\label{sec:pr2_charged_lepton_precision_candidate}", "Charged-lepton section label present");
    AssertTextContains("SRC007", PR2_source_label, text, "0.510984463", "Electron candidate target present");
    AssertTextContains("SRC008", PR2_source_label, text, "0.117861507469150", "Strong-coupling target present");
    AssertTextContains("SRC009", PR2_source_label, text, "0.08776758507426047", "QCD Lambda_6 target present");
    AssertTextContains("SRC010", PR2_source_label, text, "3.152605677", "CKM Jarlskog target present");
    AssertTextContains("SRC011", PR2_source_label, text, "-8.935540", "PMNS Jarlskog target present");
    AssertTextContains("SRC012", PR2_source_label, text, "1.507694477", "m_beta_beta target present");
end proc:

PR2_WriteEquationMap := proc(filename)
    global results, result_count, boundary_rows, PR2_source_repo, PR2_source_branch, PR2_source_path;
    local fh, i, status, paper_id;
    fh := fopen(filename, WRITE, TEXT);
    fprintf(fh, "# Projection Relativity II Equation Map\n\n");
    fprintf(fh, "Generated by `PR2_WriteEquationMap` inside the PR-II Maple harness.\n\n");
    fprintf(fh, "Source: `%s`, branch `%s`, local source fixture `%s`\n\n",
            PR2_source_repo, PR2_source_branch, PR2_source_path);
    fprintf(fh, "| paper_id | paper_location | maple_proc | maple_assert_label | status |\n");
    fprintf(fh, "| --- | --- | --- | --- | --- |\n");
    for i to result_count do
        paper_id := results[i]["id"];
        status := results[i]["status"];
        fprintf(fh, "| %s | %s | `%s` | %s | %s |\n",
                paper_id, results[i]["section"], "RunPR2Tests/PR2_SourceTextCoverageAudit",
                results[i]["note"], status);
    end do;
    for i to nops(boundary_rows) do
        fprintf(fh, "| BOUNDARY-%03d | Boundary ledger | `PR2_BoundaryNotes` | %s | %s |\n",
                i, boundary_rows[i][2], boundary_rows[i][1]);
    end do;
    fclose(fh);
end proc:

PR2_WriteProofReport := proc(filename)
    global proof_rows;
    local fh, i, row;
    fh := fopen(filename, WRITE, TEXT);
    fprintf(fh, "# Projection Relativity II Maple Proof Report\n\n");
    fprintf(fh, "Each entry records the proof method and residual/result for a passing assertion.\n\n");
    for i to nops(proof_rows) do
        row := proof_rows[i];
        fprintf(fh, "## %s - %s\n\n", row[1], row[4]);
        fprintf(fh, "- paper_location: %s\n", row[2]);
        fprintf(fh, "- kind: %s\n", row[3]);
        fprintf(fh, "- actual: `%s`\n", row[5]);
        fprintf(fh, "- expected: `%s`\n", row[6]);
        fprintf(fh, "- residual_or_error: `%s`\n", row[7]);
        fprintf(fh, "- tolerance: `%s`\n\n", row[8]);
    end do;
    fclose(fh);
end proc:

PR2_WriteHarnessValidation := proc(filename)
    global selftest_rows, selftest_count;
    local fh, i;
    fh := fopen(filename, WRITE, TEXT);
    fprintf(fh, "# Projection Relativity II Harness Self-Validation\n\n");
    fprintf(fh, "The self-tests are negative controls: they insert known-bad equations and confirm the harness rejects them.\n\n");
    fprintf(fh, "```text\nSELFTEST PASS count: %d\n```\n\n", selftest_count);
    fprintf(fh, "| selftest_label | status |\n");
    fprintf(fh, "| --- | --- |\n");
    for i to nops(selftest_rows) do
        fprintf(fh, "| %s | %s |\n", selftest_rows[i][1], selftest_rows[i][2]);
    end do;
    fclose(fh);
end proc:

PR2_WriteDerivationReport := proc(filename)
    global derivation_rows;
    local fh, i, row;
    fh := fopen(filename, WRITE, TEXT);
    fprintf(fh, "# Projection Relativity II Core Equation Derivations\n\n");
    fprintf(fh, "This report records Maple-side derivation routes for central equations in the PR-II harness.\n\n");
    for i to nops(derivation_rows) do
        row := derivation_rows[i];
        fprintf(fh, "## %s - %s\n\n", row[1], row[4]);
        fprintf(fh, "- paper_location: %s\n", row[2]);
        fprintf(fh, "- maple_proc: `%s`\n", row[3]);
        fprintf(fh, "- start: `%s`\n", row[5]);
        fprintf(fh, "- maple_step: %s\n", row[6]);
        fprintf(fh, "- result: `%s`\n\n", row[7]);
    end do;
    fclose(fh);
end proc:

PR2_WriteQCDReport := proc(filename)
    global results, result_count;
    local fh, i;
    fh := fopen(filename, WRITE, TEXT);
    fprintf(fh, "# PR-II QCD Threshold Recompute\n\n");
    fprintf(fh, "Selected QCD checks reconstructed by the Maple harness.\n\n");
    fprintf(fh, "| id | quantity | Maple recompute | manuscript reference | abs error | tolerance | status |\n");
    fprintf(fh, "| --- | --- | --- | --- | --- | --- | --- |\n");
    for i to result_count do
        if Search("Q", results[i]["id"]) = 1 then
            fprintf(fh, "| %s | %s | `%s` | `%s` | `%s` | `%s` | %s |\n",
                    results[i]["id"], results[i]["note"], results[i]["actual"],
                    results[i]["expected"], results[i]["error"],
                    results[i]["tolerance"], results[i]["status"]);
        end if;
    end do;
    fclose(fh);
end proc:

PR2_WriteEquationAudit := proc(filename)
    global result_count, proof_rows, selftest_count, boundary_rows, PR2_source_path;
    local fh, fail_count, note_count, data_count, assumption_count, manuscript_count;
    fail_count := CountFailures();
    note_count := PR2_CountBoundary("NOTE");
    data_count := PR2_CountBoundary("DATA");
    assumption_count := PR2_CountBoundary("ASSUMPTION");
    manuscript_count := PR2_CountBoundary("MANUSCRIPT");

    fh := fopen(filename, WRITE, TEXT);
    fprintf(fh, "# Projection Relativity II Equation Audit\n\n");
    fprintf(fh, "Generated by `PR2_WriteEquationAudit` inside the PR-II Maple harness.\n\n");
    fprintf(fh, "## Latest Maple Run Summary\n\n");
    fprintf(fh, "```text\n");
    fprintf(fh, "PASS count: %d\n", result_count - fail_count);
    fprintf(fh, "FAIL count: %d\n", fail_count);
    fprintf(fh, "Boundary count: %d\n", nops(boundary_rows));
    fprintf(fh, "  ASSUMPTION count: %d\n", assumption_count);
    fprintf(fh, "  DATA count: %d\n", data_count);
    fprintf(fh, "  MANUSCRIPT count: %d\n", manuscript_count);
    fprintf(fh, "  NOTE count: %d\n", note_count);
    fprintf(fh, "SELFTEST PASS count: %d\n", selftest_count);
    fprintf(fh, "PROOF REPORT entries: %d\n", nops(proof_rows));
    fprintf(fh, "```\n\n");
    fprintf(fh, "## Direct Maple Coverage\n\n");
    fprintf(fh, "- Compact non-Abelian SU(2) algebra, Casimirs, ladder maps, and charge commutators.\n");
    fprintf(fh, "- Electroweak locking, neutral mass matrix, photon masslessness, rho identity, Fermi limit, and scalar coupling ratios.\n");
    fprintf(fh, "- PR-I boundary constants, weak mixing, hierarchy action, weak scale, Fermi constant, and diagnostic W/Z masses.\n");
    fprintf(fh, "- One-generation and three-generation anomaly cancellation.\n");
    fprintf(fh, "- Generation sheets, sector-specific overlaps, and hypercharge-neutral order terms.\n");
    fprintf(fh, "- Charged-lepton Koide sheet identity and generated mass residuals.\n");
    fprintf(fh, "- QCD strong-coupling candidate, three-loop Lambda matching, threshold continuity, and quark hierarchy.\n");
    fprintf(fh, "- CKM/PMNS matrices, unitarity residuals, and Jarlskog invariants.\n");
    fprintf(fh, "- Normal-ordering neutrino spectrum, Majorana phase boundary, m_beta, m_beta_beta, and Majorana matrix symmetry.\n");
    fprintf(fh, "- Source-text coverage against `%s`.\n\n", PR2_source_path);
    fprintf(fh, "## Boundary Interpretation\n\n");
    fprintf(fh, "- `MANUSCRIPT` rows are reserved for unresolved paper-cleanup items; the current source has none.\n");
    fprintf(fh, "- `DATA` rows mark post-generation diagnostic references or external precision layers.\n");
    fprintf(fh, "- `NOTE` and `ASSUMPTION` rows record honest limits of the Maple-checkable PR-II scope.\n");
    fprintf(fh, "\n## Full Source Equation Coverage\n\n");
    fprintf(fh, "Run `scripts/equation_coverage.py` after the Maple harness to refresh `source_equation_coverage.md` and `source_equation_inventory.csv`.\n");
    fprintf(fh, "Those files inventory every top-level display math block in `%s` and require `Unmapped display blocks: 0` for full source coverage.\n", PR2_source_path);
    fclose(fh);
end proc:

PR2_RunAll := proc()
    local fail_count;
    ResetPR2HarnessState();
    printf("\n=== Projection Relativity II Maple Verification ===\n");
    RunPR2Tests();
    PR2_SourceTextCoverageAudit();
    PR2_SourceEquationFullAudit();
    PR2_BoundaryNotes();
    PR2_HarnessSelfTest();
    PR2_RecordCoreDerivations();

    fail_count := CountFailures();
    printf("\n=== Summary ===\n");
    printf("PASS count: %d\n", result_count - fail_count);
    printf("FAIL count: %d\n", fail_count);
    printf("Boundary count: %d\n", nops(boundary_rows));
    printf("  ASSUMPTION count: %d\n", PR2_CountBoundary("ASSUMPTION"));
    printf("  DATA count: %d\n", PR2_CountBoundary("DATA"));
    printf("  MANUSCRIPT count: %d\n", PR2_CountBoundary("MANUSCRIPT"));
    printf("  NOTE count: %d\n", PR2_CountBoundary("NOTE"));
    printf("SELFTEST PASS count: %d\n", selftest_count);
    printf("PROOF REPORT entries: %d\n", nops(proof_rows));
    printf("PR-II Maple verification completed.\n");

    WriteReports("reports", "pr2_maple");
    PR2_WriteEquationMap("equation_map.md");
    PR2_WriteHarnessValidation("harness_validation.md");
    PR2_WriteDerivationReport("equation_derivations.md");
    PR2_WriteProofReport("proof_report.md");
    PR2_WriteQCDReport("qcd_threshold_recompute.md");
    PR2_WriteEquationAudit("equation_audit.md");
end proc:

WriteReports := proc(report_dir, prefix)
    global results, result_count;
    local i, pass_count, fail_count, fh, summary_path, csv_path, trace_path, fail_path;

    if not FileTools:-Exists(report_dir) then
        FileTools:-MakeDirectory(report_dir);
    end if;

    fail_count := CountFailures();
    pass_count := result_count - fail_count;

    summary_path := cat(report_dir, "/", prefix, "_summary.md");
    csv_path := cat(report_dir, "/", prefix, "_results.csv");
    trace_path := cat(report_dir, "/", prefix, "_traceability.csv");
    fail_path := cat(report_dir, "/", prefix, "_failures.md");

    fh := fopen(summary_path, WRITE);
    fprintf(fh, "# PR-II Maple Test Summary\n\n");
    fprintf(fh, "Execution engine: Maple\n\n");
    fprintf(fh, "- Total tests: %d\n", result_count);
    fprintf(fh, "- Passed: %d\n", pass_count);
    fprintf(fh, "- Failed: %d\n\n", fail_count);
    fprintf(fh, "## Failed Tests\n\n");
    if fail_count = 0 then
        fprintf(fh, "No failures.\n");
    else
        for i to result_count do
            if results[i]["status"] = "FAIL" then
                fprintf(fh, "- `%s` (%s): %s\n",
                        results[i]["id"], results[i]["section"], results[i]["note"]);
            end if;
        end do;
    end if;
    fclose(fh);

    fh := fopen(csv_path, WRITE);
    fprintf(fh, "id,section,kind,status,actual,expected,error,tolerance,note\n");
    for i to result_count do
        fprintf(fh, "%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                Csv(results[i]["id"]), Csv(results[i]["section"]),
                Csv(results[i]["kind"]), Csv(results[i]["status"]),
                Csv(results[i]["actual"]), Csv(results[i]["expected"]),
                Csv(results[i]["error"]), Csv(results[i]["tolerance"]),
                Csv(results[i]["note"]));
    end do;
    fclose(fh);

    fh := fopen(trace_path, WRITE);
    fprintf(fh, "id,section,status,note\n");
    for i to result_count do
        fprintf(fh, "%s,%s,%s,%s\n",
                Csv(results[i]["id"]), Csv(results[i]["section"]),
                Csv(results[i]["status"]), Csv(results[i]["note"]));
    end do;
    fclose(fh);

    fh := fopen(fail_path, WRITE);
    fprintf(fh, "# PR-II Maple Failures\n\n");
    if fail_count = 0 then
        fprintf(fh, "No failures.\n");
    else
        for i to result_count do
            if results[i]["status"] = "FAIL" then
                fprintf(fh, "## %s\n\n", results[i]["id"]);
                fprintf(fh, "- Section: %s\n", results[i]["section"]);
                fprintf(fh, "- Note: %s\n", results[i]["note"]);
                fprintf(fh, "- Actual: `%s`\n", results[i]["actual"]);
                fprintf(fh, "- Expected: `%s`\n", results[i]["expected"]);
                fprintf(fh, "- Error: `%s`\n", results[i]["error"]);
                fprintf(fh, "- Tolerance: `%s`\n\n", results[i]["tolerance"]);
            end if;
        end do;
    end if;
    fclose(fh);
end proc:
