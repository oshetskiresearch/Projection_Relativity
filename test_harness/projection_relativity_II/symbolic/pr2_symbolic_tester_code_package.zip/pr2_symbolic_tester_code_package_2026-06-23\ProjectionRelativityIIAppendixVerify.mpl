# Projection Relativity II paper and appendix verification harness for Maple.
#
# Usage in Maple:
#   currentdir(".../pr2_maple_test_harness"):
#   read "ProjectionRelativityIIAppendixVerify.mpl":
#   PR2_RunAll();
#
# This wrapper loads the PR-II harness implementation and exposes PR2_RunAll().

Digits := 60:

read "src/pr2_harness.mpl":
read "src/pr2_tests.mpl":
read "src/pr2_source_equation_audit.mpl":
