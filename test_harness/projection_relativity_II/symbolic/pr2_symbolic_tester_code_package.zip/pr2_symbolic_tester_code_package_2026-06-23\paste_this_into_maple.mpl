restart:
currentdir("C:/Users/Michael Oshetski/Documents/Codex/2026-06-17/files-mentioned-by-the-user-paper/outputs/pr2_maple_test_harness"):
read "ProjectionRelativityIIAppendixVerify.mpl":
PR2_RunAll();

