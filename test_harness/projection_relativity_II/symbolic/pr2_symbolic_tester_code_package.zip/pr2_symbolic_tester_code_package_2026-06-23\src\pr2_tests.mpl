RunPR2Tests := proc()
    local tol, tight, loose,
          sigma1, sigma2, sigma3, T1, T2, T3, Tplus, Tminus, up, down,
          QY1, Phi0, g0, gp0, vv, M0, MW2s, MZ2s, cos2s, gZ2s,
          q_bc, c_bc, mu_min2, alpha_inv, rG, Delta, TY, sin2, cos2, tanW,
          Xi, yT, Mpl, Sbase, dS, Stotal, LambdaEW, vEW, GF, vRef, GFRef,
          alphaInvMZ, eMZ, gMZ, gpMZ, MWdiag, MZdiag,
          Ngen, eta1, eta2, eta3, y1, y2, y3, ratio,
          Cl, Cu, Cd, CnuD, kappal, kappau, kappad, kappanu, Dl, Du, Dd, Dnu,
          C1, C2, thetaK, k0, k1, k2, MlMeV, me, mmu, mtau, koide,
          alpha3, AEW, mut, mub, muc, L6, L5, L4, L3, bMZ, cAtb, cMZ,
          Cconf, ms, md, mu, lambdaPR, ACKM, Rb, deltaCKM, s12, s23, s13,
          Vckm, VckmAbs, VckmExpected, Jckm,
          pmns12, pmns23, pmns13, theta12, theta23, theta13, deltaCP,
          Upmns, UpmnsAbs, UpmnsExpected, Jpmns,
          Cnu, m1, m2, m3, dm21, dm31, R21, sumNu, mbeta, ynuDirac,
          phiM, alpha31, mbb, Mnu, Dmaj, i, j, k,
          GeV_to_eV;

    tol := 10^(-12);
    tight := 10^(-10);
    loose := 10^(-6);

    # Shared constants from the PR-I boundary ledger.
    q_bc := 10.905007182855176;
    c_bc := 3354902985/4211081216;
    mu_min2 := 3.052966743096;
    alpha_inv := 137.036361812007;
    rG := evalf(c_bc/q_bc);
    Delta := evalf((1 - c_bc)/q_bc);
    TY := 1/4;
    sin2 := evalf(TY - Delta);
    cos2 := evalf(1 - sin2);
    tanW := evalf(sqrt(sin2/cos2));
    Xi := evalf(q_bc*c_bc*sin2);
    yT := evalf(sqrt(2/Xi));
    Mpl := 2.4353234593382036*10^18;
    Sbase := evalf(Pi*q_bc + ln(q_bc/c_bc) + ln(4/3) + (TY - sin2)*(1 + c_bc)/2);
    dS := evalf(-1/2*(1 + 3*c_bc)*Delta^2);
    Stotal := evalf(Sbase + dS);
    LambdaEW := evalf(Mpl*exp(-Stotal));
    vEW := evalf(LambdaEW*sqrt(Xi));
    GF := evalf(1/(sqrt(2)*vEW^2));
    vRef := 246.2196507941374;
    GFRef := evalf(1/(sqrt(2)*vRef^2));
    AEW := evalf((1 + 3*c_bc)/2);
    C1 := evalf(1 - Delta*c_bc/4);
    C2 := evalf(1 - rG*Delta*(1 + c_bc)/2);
    Cconf := evalf((1 + c_bc)/2);

    # SU(2) algebra and compact projection.
    sigma1 := Matrix([[0, 1], [1, 0]]);
    sigma2 := Matrix([[0, -I], [I, 0]]);
    sigma3 := Matrix([[1, 0], [0, -1]]);
    T1 := (1/2)*sigma1;
    T2 := (1/2)*sigma2;
    T3 := (1/2)*sigma3;
    Tplus := T1 + I*T2;
    Tminus := T1 - I*T2;
    up := Vector([1, 0]);
    down := Vector([0, 1]);

    AssertMatrixClose("G001", "sec:pr2_nonabelian_generator_algebra", T1.T2 - T2.T1, I*T3, 0, "[T1,T2]=iT3");
    AssertMatrixClose("G002", "sec:pr2_nonabelian_generator_algebra", T2.T3 - T3.T2, I*T1, 0, "[T2,T3]=iT1");
    AssertMatrixClose("G003", "sec:pr2_nonabelian_generator_algebra", T3.T1 - T1.T3, I*T2, 0, "[T3,T1]=iT2");
    AssertExact("G004", "sec:pr2_nonabelian_generator_algebra", Trace(T1.T1), 1/2, "Trace normalization for T1");
    AssertExact("G005", "sec:pr2_nonabelian_generator_algebra", Trace(T2.T2), 1/2, "Trace normalization for T2");
    AssertExact("G006", "sec:pr2_nonabelian_generator_algebra", Trace(T3.T3), 1/2, "Trace normalization for T3");
    AssertExact("G007", "sec:pr2_nonabelian_generator_algebra", Trace(T1.T2), 0, "Off-diagonal trace normalization");
    AssertMatrixClose("G008", "sec:pr2_nonabelian_generator_algebra", T1.T1 + T2.T2 + T3.T3, (3/4)*IdentityMatrix(2), 0, "Fundamental Casimir is 3/4 I");
    AssertExact("G009", "sec:pr2_compact_weak_isospin_operator", 0*(0+1), 0, "j=0 spectral value numerator");
    AssertExact("G010", "sec:pr2_compact_weak_isospin_operator", (1/2)*(1/2+1), 3/4, "j=1/2 spectral value numerator");
    AssertExact("G011", "sec:pr2_compact_weak_isospin_operator", 1*(1+1), 2, "j=1 adjoint Casimir");
    AssertVectorClose("G012", "sec:pr2_charged_current_topological_ladder", Tplus.down, up, 0, "T+ raises down to up");
    AssertVectorClose("G013", "sec:pr2_charged_current_topological_ladder", Tminus.up, down, 0, "T- lowers up to down");
    AssertVectorClose("G014", "sec:pr2_charged_current_topological_ladder", Tplus.up, Vector([0,0]), 0, "T+ annihilates up");
    AssertVectorClose("G015", "sec:pr2_charged_current_topological_ladder", Tminus.down, Vector([0,0]), 0, "T- annihilates down");
    QY1 := T3 + (1/2)*IdentityMatrix(2);
    Phi0 := Vector([0, 1]);
    AssertVectorClose("G016", "sec:pr2_compact_electroweak_order_direction", QY1.Phi0, Vector([0,0]), 0, "Q annihilates the locking direction");
    AssertMatrixClose("G017", "sec:pr2_charged_current_ladder", QY1.Tplus - Tplus.QY1, Tplus, 0, "[Q,T+]=T+");
    AssertMatrixClose("G018", "sec:pr2_charged_current_ladder", QY1.Tminus - Tminus.QY1, -Tminus, 0, "[Q,T-]=-T-");

    # Electroweak mass and current ledger.
    g0 := 'g0'; gp0 := 'gp0'; vv := 'vv';
    M0 := (vv^2/4)*Matrix([[g0^2, -g0*gp0], [-g0*gp0, gp0^2]]);
    MW2s := g0^2*vv^2/4;
    MZ2s := (g0^2 + gp0^2)*vv^2/4;
    cos2s := g0^2/(g0^2 + gp0^2);
    gZ2s := g0^2 + gp0^2;
    AssertExact("EW001", "sec:pr2_electroweak_connection_mass_ledger", simplify(Determinant(M0)), 0, "Neutral mass matrix has zero determinant");
    AssertExact("EW002", "sec:pr2_electroweak_connection_mass_ledger", simplify(Trace(M0)), MZ2s, "Nonzero neutral eigenvalue is MZ^2");
    AssertExact("EW003", "sec:pr2_tree_level_electroweak_consistency", simplify(MW2s/(MZ2s*cos2s)), 1, "rho_EW tree-level identity");
    AssertExact("EW004", "sec:pr2_charged_weak_projection_fermi_limit", simplify(g0^2/(8*MW2s)), 1/(2*vv^2), "Charged Fermi contact coefficient");
    AssertExact("EW005", "sec:pr2_neutral_current_projection", simplify(gZ2s/(8*MZ2s)), 1/(2*vv^2), "Neutral-current contact coefficient");
    AssertExact("EW006", "sec:pr2_compact_order_field_counting", (3+1)-1, 3, "Broken compact directions");
    AssertExact("EW007", "sec:pr2_compact_order_field_counting", 4-3, 1, "One scalar order-mode remains");
    AssertExact("EW008", "sec:pr2_order_mode_gauge_boson_couplings", simplify(2*MW2s/vv), g0^2*vv/2, "hWW coupling ratio");
    AssertExact("EW009", "sec:pr2_order_mode_gauge_boson_couplings", simplify(2*MZ2s/vv), (g0^2+gp0^2)*vv/2, "hZZ coupling ratio");

    # Boundary constants, weak mixing, weak scale, and diagnostics.
    AssertClose("B001", "sec:pr2_boundary_ledger_electroweak_lift", mu_min2, 3.052966743096, tol, "Radial stiffness gap");
    AssertClose("B002", "sec:pr2_boundary_ledger_electroweak_lift", q_bc, 10.905007182855176, tol, "Compact boundary stiffness");
    AssertClose("B003", "sec:pr2_boundary_ledger_electroweak_lift", evalf(c_bc), 0.796684464847899, tol, "Compact boundary cofactor");
    AssertClose("B004", "sec:pr2_boundary_ledger_electroweak_lift", alpha_inv, 137.036361812007, tol, "PR boundary alpha inverse");
    AssertClose("B005", "sec:pr2_boundary_ledger_electroweak_lift", rG, 0.073056757459128, tol, "Generation suppression ratio");
    AssertClose("B006", "sec:pr2_weak_mixing_boundary_closure", Delta, 0.018644236701811, tol, "Normalized weak boundary deficit");
    AssertClose("B007", "sec:pr2_weak_mixing_boundary_closure", sin2, 0.231355763298189, tol, "Weak mixing sin^2");
    AssertClose("B008", "sec:pr2_weak_mixing_boundary_closure", cos2, 0.768644236701811, tol, "Weak mixing cos^2");
    AssertClose("B009", "sec:pr2_weak_mixing_boundary_closure", tanW, 0.548627374785032, tol, "g'/g = tan theta_W");
    AssertClose("B010", "sec:pr2_dimensionless_weak_order_factor", Xi, 2.0099841245909515, tol, "Dimensionless weak-order factor");
    AssertClose("B011", "sec:pr2_dimensionless_weak_order_factor", sqrt(Xi), 1.417739089039641, tol, "sqrt Xi");
    AssertClose("B012", "sec:pr2_terminal_weak_displacement_overlap", yT, 0.997513275401799, tol, "Terminal weak overlap");
    AssertClose("B013", "sec:pr2_compact_spectral_hierarchy_action", Sbase, 37.18004007116382, tol, "Base hierarchy action");
    AssertClose("B014", "sec:pr2_compact_spectral_hierarchy_action", dS, -5.892040980909848*10^(-4), tol, "Second-order action correction");
    AssertClose("B015", "sec:pr2_compact_spectral_hierarchy_action", Stotal, 37.17945086706573, tol, "Total hierarchy action");
    AssertClose("B016", "sec:pr2_compact_spectral_hierarchy_action", LambdaEW, 173.67059834472832, tight, "Weak displacement anchor");
    AssertClose("B017", "sec:pr2_generated_weak_scale_fermi_constant", vEW, 246.21959589022453, tight, "Generated electroweak vacuum scale");
    AssertClose("B018", "sec:pr2_generated_weak_scale_fermi_constant", GF, 1.166379220175995*10^(-5), 10^(-16), "Generated Fermi constant");
    AssertClose("B019", "sec:pr2_generated_weak_scale_fermi_constant", (vEW-vRef)/vRef, -2.23*10^(-7), 10^(-9), "Weak-scale diagnostic residual");
    AssertClose("B020", "sec:pr2_generated_weak_scale_fermi_constant", (GF-GFRef)/GFRef, 4.46*10^(-7), 10^(-9), "Fermi diagnostic residual");

    alphaInvMZ := 127.955;
    eMZ := sqrt(4*Pi/alphaInvMZ);
    gMZ := evalf(eMZ/sqrt(sin2));
    gpMZ := evalf(eMZ/sqrt(cos2));
    MWdiag := evalf(gMZ*vEW/2);
    MZdiag := evalf(sqrt(gMZ^2 + gpMZ^2)*vEW/2);
    AssertClose("B021", "sec:pr2_mass_geometry_diagnostic_coupling", MWdiag, 80.210045, 10^(-6), "Diagnostic W mass using alpha(MZ)^-1");
    AssertClose("B022", "sec:pr2_mass_geometry_diagnostic_coupling", MZdiag, 91.488408, 10^(-6), "Diagnostic Z mass using alpha(MZ)^-1");

    # Charge assignments and anomaly cancellation.
    AssertExact("A001", "sec:pr2_residual_em_charges_fermion_ledger", 1/2 + (1/3)/2, 2/3, "u_L charge");
    AssertExact("A002", "sec:pr2_residual_em_charges_fermion_ledger", -1/2 + (1/3)/2, -1/3, "d_L charge");
    AssertExact("A003", "sec:pr2_residual_em_charges_fermion_ledger", 1/2 + (-1)/2, 0, "nu_L charge");
    AssertExact("A004", "sec:pr2_residual_em_charges_fermion_ledger", -1/2 + (-1)/2, -1, "e_L charge");
    AssertExact("A005", "sec:pr2_pure_color_anomaly", 2 - 1 - 1, 0, "Pure color anomaly");
    AssertExact("A006", "sec:pr2_mixed_color_hypercharge_anomaly", 2*(1/2)*(1/3) + (1/2)*(-4/3) + (1/2)*(2/3), 0, "Mixed color-hypercharge anomaly");
    AssertExact("A007", "sec:pr2_mixed_weak_hypercharge_anomaly", 3*(1/2)*(1/3) + (1/2)*(-1), 0, "Mixed weak-hypercharge anomaly");
    AssertExact("A008", "sec:pr2_mixed_gravitational_hypercharge_anomaly", 6*(1/3) + 3*(-4/3) + 3*(2/3) + 2*(-1) + 2, 0, "Mixed gravitational-hypercharge anomaly");
    AssertExact("A009", "sec:pr2_cubic_hypercharge_anomaly", 6*(1/3)^3 + 3*(-4/3)^3 + 3*(2/3)^3 + 2*(-1)^3 + 2^3, 0, "Cubic hypercharge anomaly");
    AssertTrue("A010", "sec:pr2_witten_global_anomaly", type(4/2, integer), "One-generation Witten parity");
    AssertTrue("A011", "sec:pr2_three_sheet_representation_ledger", type(12/2, integer), "Three-generation Witten parity");

    # Generation sheets and overlap ledgers.
    Ngen := (3+1)-1;
    eta1 := evalf(rG^2);
    eta2 := rG;
    eta3 := 1;
    y1 := evalf(yT*eta1);
    y2 := evalf(yT*eta2);
    y3 := yT;
    ratio := evalf(q_bc/c_bc);
    AssertExact("F001", "sec:pr2_generation_origin_flavor_sheets", Ngen, 3, "Generation count from compact quotient");
    AssertClose("F002", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta1, 0.005337289810442, tol, "First sheet eta");
    AssertClose("F003", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta2, 0.073056757459128, tol, "Second sheet eta");
    AssertClose("F004", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta3, 1, tol, "Third sheet eta");
    AssertTrue("F005", "sec:pr2_generation_sheet_overlap_hierarchy_main", eta1 < eta2 and eta2 < eta3, "Sheet hierarchy ordering");
    AssertClose("F006", "sec:pr2_generation_sheet_overlap_hierarchy_main", ratio, 13.6879877341867, 10^(-10), "Successive hierarchy ratio");
    AssertClose("F007", "sec:pr2_generation_sheet_overlap_hierarchy_main", y1, 0.005324017440582, tol, "First terminal matter overlap");
    AssertClose("F008", "sec:pr2_generation_sheet_overlap_hierarchy_main", y2, 0.072875085423290, tol, "Second terminal matter overlap");
    AssertClose("F009", "sec:pr2_generation_sheet_overlap_hierarchy_main", y3, 0.997513275401799, tol, "Third terminal matter overlap");

    Cl := 2; Cu := 23/9; Cd := 20/9; CnuD := 1;
    kappal := evalf(1 + rG*Cl);
    kappau := evalf(1 + rG*Cu);
    kappad := evalf(1 + rG*Cd);
    kappanu := evalf(1 + rG*CnuD);
    Dl := Matrix([[kappal*y1,0,0],[0,kappal*y2,0],[0,0,kappal*y3]]);
    Du := Matrix([[kappau*y1,0,0],[0,kappau*y2,0],[0,0,kappau*y3]]);
    Dd := Matrix([[kappad*y1,0,0],[0,kappad*y2,0],[0,0,kappad*y3]]);
    Dnu := Matrix([[kappanu*y1,0,0],[0,kappanu*y2,0],[0,0,kappanu*y3]]);
    AssertClose("F010", "sec:pr2_sector_specific_compact_charge_norms", kappal, 1.146113514918256, tol, "Charged-lepton sector factor");
    AssertClose("F011", "sec:pr2_sector_specific_compact_charge_norms", kappau, 1.186700602395549, tol, "Up-quark sector factor");
    AssertClose("F012", "sec:pr2_sector_specific_compact_charge_norms", kappad, 1.162348349909173, tol, "Down-quark sector factor");
    AssertClose("F013", "sec:pr2_sector_specific_compact_charge_norms", kappanu, 1.073056757459128, tol, "Dirac-neutrino sector factor");
    AssertClose("F014", "sec:pr2_sector_specific_overlap_spectra", Dl[1,1], 0.006101928, 10^(-9), "D_l first entry");
    AssertClose("F015", "sec:pr2_sector_specific_overlap_spectra", Dl[2,2], 0.083523120, 10^(-9), "D_l second entry");
    AssertClose("F016", "sec:pr2_sector_specific_overlap_spectra", Dl[3,3], 1.143263446, 10^(-9), "D_l third entry");
    AssertClose("F017", "sec:pr2_sector_specific_overlap_spectra", Du[3,3]/Dd[3,3], 1.02095090726311, tol, "Up/down sheetwise sector ratio");
    AssertExact("F018", "sec:pr2_hypercharge_neutral_order_terms", -(-1)+1+(-2), 0, "Charged-lepton hypercharge neutrality");
    AssertExact("F019", "sec:pr2_hypercharge_neutral_order_terms", -(1/3)+1+(-2/3), 0, "Down-quark hypercharge neutrality");
    AssertExact("F020", "sec:pr2_hypercharge_neutral_order_terms", -(1/3)-1+(4/3), 0, "Up-quark hypercharge neutrality");
    AssertExact("F021", "sec:pr2_hypercharge_neutral_order_terms", -(-1)-1+0, 0, "Dirac-neutrino hypercharge neutrality");

    # Charged-lepton Koide sheet candidate.
    thetaK := evalf(2/Ngen^2);
    k0 := evalf((1 + sqrt(2)*cos(thetaK + 2*Pi*0/3))^2);
    k1 := evalf((1 + sqrt(2)*cos(thetaK + 2*Pi*1/3))^2);
    k2 := evalf((1 + sqrt(2)*cos(thetaK + 2*Pi*2/3))^2);
    MlMeV := evalf(1000*LambdaEW*rG*Delta*(4/3)*C1*C2);
    mtau := evalf(MlMeV*k0);
    me := evalf(MlMeV*k1);
    mmu := evalf(MlMeV*k2);
    koide := evalf((me + mmu + mtau)/(sqrt(me) + sqrt(mmu) + sqrt(mtau))^2);
    AssertClose("L001", "sec:pr2_three_sheet_square_root_flavor_geometry", thetaK, 2/9, tol, "Koide sheet phase");
    AssertClose("L002", "sec:pr2_koide_identity_three_sheet_geometry", cos(thetaK)+cos(thetaK+2*Pi/3)+cos(thetaK+4*Pi/3), 0, tol, "Three-sheet cosine sum");
    AssertClose("L003", "sec:pr2_koide_identity_three_sheet_geometry", cos(thetaK)^2+cos(thetaK+2*Pi/3)^2+cos(thetaK+4*Pi/3)^2, 3/2, tol, "Three-sheet cosine-square sum");
    AssertClose("L004", "sec:pr2_charged_lepton_compact_scale", C1, 0.996286606565180, tol, "Charged-lepton C1");
    AssertClose("L005", "sec:pr2_charged_lepton_compact_scale", C2, 0.998776379293597, tol, "Charged-lepton C2");
    AssertClose("L006", "sec:pr2_charged_lepton_compact_scale", MlMeV, 313.850332183, 10^(-9), "Charged-lepton compact scale in MeV");
    AssertClose("L007", "sec:pr2_generated_charged_lepton_masses", me, 0.510984463, 10^(-9), "Electron mass candidate");
    AssertClose("L008", "sec:pr2_generated_charged_lepton_masses", mmu, 105.656418843, 10^(-9), "Muon mass candidate");
    AssertClose("L009", "sec:pr2_generated_charged_lepton_masses", mtau, 1776.934589789, 10^(-9), "Tau mass candidate");
    AssertClose("L010", "sec:pr2_koide_identity_three_sheet_geometry", koide, 2/3, tol, "Koide ratio");
    AssertClose("L011", "sec:pr2_generated_charged_lepton_masses", (me-0.510998950)/0.510998950*10^6, -28.35, 10^(-2), "Electron ppm residual");
    AssertClose("L012", "sec:pr2_generated_charged_lepton_masses", (mmu-105.6583755)/105.6583755*10^6, -18.52, 10^(-2), "Muon ppm residual");
    AssertClose("L013", "sec:pr2_generated_charged_lepton_masses", (mtau-1776.930)/1776.930*10^6, 2.58, 10^(-2), "Tau ppm residual");

    # QCD and quark hierarchy.
    alpha3 := evalf(1/(q_bc*c_bc - (1 - c_bc)));
    mut := evalf(LambdaEW*C1*C2);
    mub := evalf(LambdaEW*(rG/3)*(1 - Delta*c_bc));
    muc := evalf(LambdaEW*rG^2*(4/3)*(1 + Delta*AEW));
    AssertClose("Q001", "sec:pr2_compact_boundary_strong_coupling_candidate", alpha3, 0.117861507469150, tol, "Compact strong-coupling candidate");
    AssertClose("Q002", "sec:pr2_pr_derived_heavy_quark_thresholds", mut, 172.8139732666624, tight, "Top threshold candidate");
    AssertClose("Q003", "sec:pr2_pr_derived_heavy_quark_thresholds", mub, 4.1664504826753515, tol, "Bottom threshold candidate");
    AssertClose("Q004", "sec:pr2_pr_derived_heavy_quark_thresholds", muc, 1.274964814257465, tol, "Charm threshold candidate");
    AssertTrue("Q005", "sec:pr2_pr_derived_heavy_quark_thresholds", mut > mub and mub > muc and muc > 0, "Heavy-threshold ordering");
    AssertExact("Q006", "sec:pr2_qcd_running_ledger_main", 11 - 2*3/3, 9, "beta0 for nf=3");
    AssertExact("Q007", "sec:pr2_qcd_running_ledger_main", 11 - 2*4/3, 25/3, "beta0 for nf=4");
    AssertExact("Q008", "sec:pr2_qcd_running_ledger_main", 11 - 2*5/3, 23/3, "beta0 for nf=5");
    AssertExact("Q009", "sec:pr2_qcd_running_ledger_main", 11 - 2*6/3, 7, "beta0 for nf=6");
    AssertExact("Q010", "sec:pr2_qcd_running_ledger_main", 12/(33-2*5), 12/23, "Mass-running exponent for nf=5");

    L5 := SolveLambda3Loop(MZdiag, alpha3, 5);
    L6 := SolveLambda3Loop(mut, Alpha3Loop(mut, L5, 5), 6);
    L4 := SolveLambda3Loop(mub, Alpha3Loop(mub, L5, 5), 4);
    L3 := SolveLambda3Loop(muc, Alpha3Loop(muc, L4, 4), 3);
    bMZ := MassRun1Loop(mub, mub, MZdiag, 5, L5);
    cAtb := MassRun1Loop(muc, muc, mub, 4, L4);
    cMZ := MassRun1Loop(cAtb, mub, MZdiag, 5, L5);
    AssertClose("Q011", "sec:pr2_qcd_threshold_ledger", L6, 0.08776758507426047, 10^(-12), "Lambda_6 from three-loop matching");
    AssertClose("Q012", "sec:pr2_qcd_threshold_ledger", L5, 0.2074330873004123, 10^(-12), "Lambda_5 from alpha_3 at MZ");
    AssertClose("Q013", "sec:pr2_qcd_threshold_ledger", L4, 0.2861117918030313, 10^(-12), "Lambda_4 from bottom matching");
    AssertClose("Q014", "sec:pr2_qcd_threshold_ledger", L3, 0.3246524964107782, 10^(-12), "Lambda_3 from charm matching");
    AssertClose("Q015", "sec:pr2_qcd_threshold_ledger", Alpha3Loop(mut,L6,6)-Alpha3Loop(mut,L5,5), 0, 10^(-12), "Top-threshold coupling continuity");
    AssertClose("Q016", "sec:pr2_qcd_threshold_ledger", Alpha3Loop(mub,L4,4)-Alpha3Loop(mub,L5,5), 0, 10^(-12), "Bottom-threshold coupling continuity");
    AssertClose("Q017", "sec:pr2_qcd_threshold_ledger", Alpha3Loop(muc,L3,3)-Alpha3Loop(muc,L4,4), 0, 10^(-12), "Charm-threshold coupling continuity");
    AssertClose("Q018", "sec:pr2_qcd_threshold_ledger", bMZ, 2.9807846581959314, 10^(-12), "b running diagnostic at MZ");
    AssertClose("Q019", "sec:pr2_qcd_threshold_ledger", cAtb, 0.9892172861698667, 10^(-12), "c running diagnostic at bottom threshold");
    AssertClose("Q020", "sec:pr2_qcd_threshold_ledger", cMZ, 0.7077112094571149, 10^(-12), "c running diagnostic at MZ");
    AssertClose("Q021", "sec:pr2_light_sector_confinement_average_main", Cconf, 0.8983422324239495, tol, "Compact confinement average");
    AssertClose("Q022", "sec:pr2_light_sector_confinement_average_main", 2*Cconf-1, c_bc, tol, "Confinement endpoint reconstructs c_bc");
    AssertClose("Q023", "sec:pr2_light_quark_hierarchy_candidate", evalf(1000*mub*(rG/3)*(1 + Delta*AEW)*Cconf), 94.028510538, 10^(-9), "Strange-quark low-energy candidate");
    ms := evalf(1000*mub*(rG/3)*(1 + Delta*AEW)*Cconf);
    md := evalf(ms*rG*c_bc*(1 - AEW*Delta)*Cconf);
    mu := evalf(md*((1+c_bc)/4)*(1 + Delta*c_bc/4));
    AssertClose("Q024", "sec:pr2_light_quark_hierarchy_candidate", md, 4.761039493, 10^(-9), "Down-quark low-energy candidate");
    AssertClose("Q025", "sec:pr2_light_quark_hierarchy_candidate", mu, 2.146462595, 10^(-9), "Up-quark low-energy candidate");
    AssertTrue("Q026", "sec:pr2_six_quark_hierarchy_candidate", mu < md and md < ms and ms/1000 < muc and muc < mub and mub < mut, "Six-quark hierarchy ordering");

    # CKM and PMNS mixing.
    lambdaPR := evalf(sqrt(rG*c_bc*Cconf*(1 - AEW*Delta)));
    ACKM := evalf(c_bc/(1 - AEW*Delta));
    Rb := evalf((1 - rG)*c_bc/(1 + c_bc)*(1 - AEW*Delta));
    deltaCKM := evalf(Pi/3 + sqrt(Delta));
    s12 := lambdaPR;
    s23 := evalf(ACKM*lambdaPR^2);
    s13 := evalf(ACKM*lambdaPR^3*Rb);
    Vckm := CKMMatrix(s12, s23, s13, deltaCKM);
    VckmAbs := AbsMatrix(Vckm);
    VckmExpected := Matrix([[0.974347364,0.225018430,0.003730932],
                            [0.224881887,0.973495229,0.041655455],
                            [0.008680487,0.040911440,0.999125069]]);
    Jckm := Jarlskog(s12, s23, s13, deltaCKM);
    AssertClose("M001", "sec:pr2_ckm_compact_mixing_candidate", lambdaPR, 0.225019996525935, tol, "Compact Cabibbo sheet angle");
    AssertClose("M002", "sec:pr2_ckm_compact_mixing_candidate", ACKM, 0.822683296413403, tol, "Compact CKM hierarchy coefficient");
    AssertClose("M003", "sec:pr2_ckm_compact_mixing_candidate", Rb, 0.398035078485258, tol, "Compact unitarity-apex radius");
    AssertClose("M004", "sec:pr2_ckm_compact_mixing_candidate", deltaCKM, 1.1837414514697735, tol, "CKM phase in radians");
    AssertClose("M005", "sec:pr2_ckm_compact_mixing_candidate", s23, 0.041655745073430, tol, "CKM s23");
    AssertClose("M006", "sec:pr2_ckm_compact_mixing_candidate", s13, 0.003730932297278, tol, "CKM s13");
    AssertMatrixClose("M007", "sec:pr2_ckm_compact_mixing_candidate", VckmAbs, VckmExpected, 10^(-9), "CKM absolute matrix");
    AssertMatrixClose("M008", "sec:pr2_ckm_compact_mixing_candidate", HermitianTranspose(Vckm).Vckm, IdentityMatrix(3), 10^(-14), "CKM unitarity");
    AssertClose("M009", "sec:pr2_ckm_compact_mixing_candidate", Jckm, 3.152605677*10^(-5), 10^(-13), "CKM Jarlskog invariant");

    pmns12 := evalf(Cconf/Ngen);
    pmns23 := evalf(AEW/Ngen);
    pmns13 := evalf(Delta*(1+rG)/Cconf);
    theta12 := evalf(arcsin(sqrt(pmns12))*180/Pi);
    theta23 := evalf(arcsin(sqrt(pmns23))*180/Pi);
    theta13 := evalf(arcsin(sqrt(pmns13))*180/Pi);
    deltaCP := evalf(Pi + 2*sqrt(Delta));
    Upmns := CKMMatrix(sqrt(pmns12), sqrt(pmns23), sqrt(pmns13), deltaCP);
    UpmnsAbs := AbsMatrix(Upmns);
    UpmnsExpected := Matrix([[0.827618,0.541090,0.149232],
                             [0.271685,0.611360,0.743254],
                             [0.491158,0.577460,0.652153]]);
    Jpmns := Jarlskog(sqrt(pmns12), sqrt(pmns23), sqrt(pmns13), deltaCP);
    AssertClose("M010", "sec:pr2_pmns_compact_lepton_mixing_candidate", pmns12, 0.299447410807983, tol, "PMNS solar sin^2");
    AssertClose("M011", "sec:pr2_pmns_compact_lepton_mixing_candidate", theta12, 33.176356643, 10^(-9), "PMNS solar angle");
    AssertClose("M012", "sec:pr2_pmns_compact_lepton_mixing_candidate", pmns23, 0.565008899090616, tol, "PMNS atmospheric sin^2");
    AssertClose("M013", "sec:pr2_pmns_compact_lepton_mixing_candidate", theta23, 48.735310403, 10^(-9), "PMNS atmospheric angle");
    AssertClose("M014", "sec:pr2_pmns_compact_lepton_mixing_candidate", pmns13, 0.022270270124743, tol, "PMNS reactor sin^2");
    AssertClose("M015", "sec:pr2_pmns_compact_lepton_mixing_candidate", theta13, 8.582438059, 10^(-9), "PMNS reactor angle");
    AssertClose("M016", "sec:pr2_pmns_compact_lepton_mixing_candidate", deltaCP, 3.414680454, 10^(-9), "PMNS CP phase");
    AssertMatrixClose("M017", "sec:pr2_pmns_compact_lepton_mixing_candidate", UpmnsAbs, UpmnsExpected, 10^(-6), "PMNS absolute matrix");
    AssertMatrixClose("M018", "sec:pr2_pmns_compact_lepton_mixing_candidate", HermitianTranspose(Upmns).Upmns, IdentityMatrix(3), 10^(-14), "PMNS unitarity");
    AssertClose("M019", "sec:pr2_pmns_compact_lepton_mixing_candidate", Jpmns, -8.935540*10^(-3), 10^(-9), "PMNS Jarlskog invariant");

    # Neutrino mass sector and Majorana boundary.
    GeV_to_eV := 10^9;
    Cnu := evalf(1 - Delta*c_bc);
    R21 := evalf(Delta*((1+c_bc)^2/2)*Cnu);
    m1 := 0;
    m3 := evalf((vEW^2/Mpl)*GeV_to_eV*rG^(-3)*c_bc*Cnu);
    m2 := evalf(sqrt(R21)*m3);
    dm21 := evalf(m2^2 - m1^2);
    dm31 := evalf(m3^2 - m1^2);
    sumNu := evalf(m1 + m2 + m3);
    mbeta := evalf(sqrt((1-pmns13)*pmns12*m2^2 + pmns13*m3^2));
    ynuDirac := evalf(sqrt(2)*m3/(vEW*GeV_to_eV));
    phiM := evalf(Pi*Cconf);
    alpha31 := evalf(phiM + 2*deltaCP);
    while evalb(alpha31 > evalf(2*Pi)) do alpha31 := alpha31 - evalf(2*Pi); end do;
    mbb := evalf(abs(m2*(1-pmns13)*pmns12 + m3*pmns13*exp(I*phiM)));
    AssertClose("N001", "sec:pr2_neutrino_normal_ordering_singlet_channel", Cnu, 0.985147, 10^(-6), "Compact neutrino loss factor");
    AssertClose("N002", "sec:pr2_neutrino_normal_ordering_singlet_channel", R21, 2.964551668*10^(-2), 10^(-11), "Solar-to-atmospheric splitting ratio");
    AssertClose("N003", "sec:pr2_generated_neutrino_spectrum", m1, 0, tol, "Massless residual compact-singlet sheet");
    AssertClose("N004", "sec:pr2_generated_neutrino_spectrum", m2, 8.627283010*10^(-3), 10^(-12), "Second neutrino mass");
    AssertClose("N005", "sec:pr2_generated_neutrino_spectrum", m3, 5.010655367*10^(-2), 2*10^(-12), "Third neutrino mass");
    AssertTrue("N006", "sec:pr2_generated_neutrino_spectrum", m1 < m2 and m2 < m3, "Normal-ordering hierarchy");
    AssertClose("N007", "sec:pr2_generated_neutrino_spectrum", dm21, 7.443001214*10^(-5), 10^(-13), "Solar mass-squared splitting");
    AssertClose("N008", "sec:pr2_generated_neutrino_spectrum", dm31, 2.510666721*10^(-3), 10^(-12), "Atmospheric mass-squared splitting");
    AssertClose("N009", "sec:pr2_generated_neutrino_spectrum", dm21/dm31, 2.964551668*10^(-2), 10^(-11), "Splitting ratio");
    AssertClose("N010", "sec:pr2_generated_neutrino_spectrum", sumNu, 5.873383668*10^(-2), 10^(-12), "Cosmological neutrino mass sum");
    AssertClose("N011", "sec:pr2_generated_neutrino_spectrum", mbeta, 8.815029410*10^(-3), 10^(-12), "Beta-decay effective mass");
    AssertClose("N012", "sec:pr2_majorana_dominant_compact_singlet_projection", ynuDirac, 2.88*10^(-13), 10^(-15), "Equivalent Dirac Yukawa diagnostic");
    AssertClose("N013", "sec:pr2_majorana_phase_boundary", phiM, 2.822225357793, 10^(-12), "Majorana interference phase");
    AssertClose("N014", "sec:pr2_majorana_phase_boundary", alpha31, 3.368400958885, 10^(-12), "Locked alpha31 phase");
    AssertClose("N015", "sec:pr2_majorana_phase_boundary", mbb, 1.507694477*10^(-3), 10^(-12), "Neutrinoless double-beta effective mass");

    Dmaj := [m1, m2*exp(0), m3*exp(I*alpha31)];
    Mnu := Matrix(3,3);
    for i to 3 do
        for j to 3 do
            Mnu[i,j] := add(conjugate(Upmns[i,k])*Dmaj[k]*conjugate(Upmns[j,k]), k=1..3);
        end do;
    end do;
    AssertMatrixClose("N016", "sec:pr2_flavor_basis_majorana_mass_matrix", Transpose(Mnu), Mnu, 10^(-14), "Flavor-basis Majorana matrix is symmetric");

end proc:
