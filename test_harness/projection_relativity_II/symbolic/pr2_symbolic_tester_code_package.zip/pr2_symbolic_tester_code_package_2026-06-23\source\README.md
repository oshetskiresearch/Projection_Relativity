# Source Folder

This folder is populated by `fetch_github_source.ps1`.

The script downloads:

```text
https://raw.githubusercontent.com/oshetskiresearch/Projection_Relativity/main/manuscript/projection_relativity_II/Oshetski_Projection_Relativity_II_Main.tex
```

Generated source files and manifests are intentionally ignored by `.gitignore`.
