from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INV = ROOT / "source_equation_inventory.csv"
RESULTS = ROOT / "reports" / "pr2_maple_results.csv"
OUT_MD = ROOT / "coverage_quality_report.md"
OUT_BACKLOG = ROOT / "direct_proof_backlog.csv"


def count_lines(path: Path) -> int:
    return len(path.read_text(encoding="utf-8", errors="replace").splitlines()) if path.exists() else 0


def main() -> int:
    rows = list(csv.DictReader(INV.open(encoding="utf-8")))
    result_rows = list(csv.DictReader(RESULTS.open(encoding="utf-8"))) if RESULTS.exists() else []

    status_counts = Counter(r["coverage_status"] for r in rows)
    mode_counts = Counter(r["coverage_mode"] for r in rows)
    direct_rows = [r for r in rows if r["coverage_mode"] in {"direct-numeric", "direct-symbolic"}]
    chain_rows = [r for r in rows if r["coverage_mode"] == "section-chain"]
    boundary_rows = [r for r in rows if r["coverage_status"] != "PASS"]
    backlog = [r for r in rows if r["coverage_mode"] not in {"direct-numeric", "direct-symbolic"}]

    harness_files = [
        ROOT / "src" / "pr2_harness.mpl",
        ROOT / "src" / "pr2_tests.mpl",
        ROOT / "src" / "pr2_source_equation_audit.mpl",
    ]
    harness_lines = sum(count_lines(path) for path in harness_files)
    harness_procs = 43 + 1 + 2
    generated_latex_assertions = len(rows) + 8
    latex_audit_already_run = any(
        r.get("id", "").startswith("LATEX-PR2-EQ-")
        or r.get("id", "") == "LATEX-DISPLAY-COUNT"
        for r in result_rows
    )
    if latex_audit_already_run:
        core_recorded_checks = max(0, len(result_rows) - generated_latex_assertions)
        expected_maple_checks = len(result_rows)
        latex_audit_line = (
            f"- Generated LaTeX-source assertions included in current Maple run: "
            f"{generated_latex_assertions}"
        )
        expected_line = f"- Current expected Maple checks: {expected_maple_checks}"
    else:
        core_recorded_checks = len(result_rows)
        expected_maple_checks = core_recorded_checks + generated_latex_assertions
        latex_audit_line = (
            f"- Generated LaTeX-source assertions ready for next Maple run: "
            f"{generated_latex_assertions}"
        )
        expected_line = f"- Expected Maple checks after rerun: {expected_maple_checks}"

    with OUT_BACKLOG.open("w", newline="", encoding="utf-8") as f:
        fields = [
            "eq_id",
            "start_line",
            "end_line",
            "section_label",
            "coverage_status",
            "coverage_mode",
            "coverage_note",
            "snippet",
        ]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in backlog:
            writer.writerow({k: row.get(k, "") for k in fields})

    lines = [
        "# PR-II Coverage Quality Report",
        "",
        "This report separates full source accounting from direct Maple proof density.",
        "",
        "## Current Harness Size",
        "",
        f"- PR-II Maple source lines: {harness_lines}",
        f"- PR-II Maple procedures: {harness_procs}",
        f"- Last recorded PR-II Maple checks: {len(result_rows)}",
        f"- Recorded non-LaTeX/core checks: {core_recorded_checks}",
        latex_audit_line,
        expected_line,
        "- Includes generated Maple source audit with one assertion per display block.",
        "",
        "For comparison, the PR-I symbolic harness inspected during development has approximately:",
        "",
        "- PR-I main Maple source lines: 1986",
        "- PR-I Maple procedures: 64",
        "",
        "## Display-Block Coverage",
        "",
        f"- Display blocks inventoried: {len(rows)}",
        f"- Unmapped display blocks: {status_counts.get('UNMAPPED', 0)}",
        f"- Direct numeric/symbolic display matches: {len(direct_rows)}",
        f"- Section-chain PASS display blocks: {len(chain_rows)}",
        f"- Boundary/context/data/manuscript display blocks: {len(boundary_rows)}",
        "",
        "## Status Counts",
        "",
        "| status | count |",
        "| --- | --- |",
    ]
    for key, count in sorted(status_counts.items()):
        lines.append(f"| {key} | {count} |")

    lines += [
        "",
        "## Coverage Mode Counts",
        "",
        "| mode | count |",
        "| --- | --- |",
    ]
    for key, count in sorted(mode_counts.items()):
        lines.append(f"| {key} | {count} |")

    lines += [
        "",
        "## Interpretation",
        "",
        "The PR-II harness now has complete source accounting, but it is not yet PR-I-parity in direct proof density.",
        "The next hardening pass should convert high-value `section-chain` and `note-boundary` rows into explicit Maple assertions or explicit PR1-style boundary notes with derivation text.",
        "",
        "Priority targets for direct-proof expansion:",
        "",
        "1. Electroweak lift/operator definitions before the main locking section.",
        "2. Residual charge matrix displays in the residual electromagnetic boundary section.",
        "3. Group-valued phase and Peter-Weyl representation displays.",
        "4. Scalar ledger definitions and PR-III-deferred equations as explicit `NOTE` rows in Maple, not only in the coverage CSV.",
        "5. Audit-map/status tables as generated report checks.",
        "",
        f"The full backlog is written to `{OUT_BACKLOG.name}`.",
    ]

    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {OUT_MD}")
    print(f"Wrote {OUT_BACKLOG}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
