# PR-II Maple Test Harness

This bundle is a Maple-first verification harness for the final GitHub PR-II manuscript:
`source/Oshetski_Projection_Relativity_II_Main.tex`.
It now follows the PR-I symbolic harness pattern: one main Maple entrypoint,
section-level traceability, proof reports, source-text coverage, boundary labels,
and negative controls.

## Run With Maple

From this directory:

```powershell
cmaple run_appendix_verification.mpl
```

For the complete release audit on Windows, including automatic GitHub source
download, regenerated source equation coverage, regenerated Maple source audit,
Maple execution, and the coverage quality report, run:

```powershell
.\run_full_audit_windows.ps1
```

If Windows blocks local PowerShell scripts, use:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run_full_audit_windows.ps1
```

The fetch step downloads:

```text
https://raw.githubusercontent.com/oshetskiresearch/Projection_Relativity/main/manuscript/projection_relativity_II/Oshetski_Projection_Relativity_II_Main.tex
```

into:

```text
source/Oshetski_Projection_Relativity_II_Main.tex
```

and writes `source/github_source_manifest.json` with the fetched SHA256.

For offline reruns against the already-fetched local source, set:

```powershell
$env:PR2_SKIP_GITHUB_FETCH="1"
.\run_full_audit_windows.ps1
```

Or in the Maple worksheet interface, first run `fetch_github_source.ps1` from
PowerShell, then set the current directory to this folder and run:

```maple
read "ProjectionRelativityIIAppendixVerify.mpl":
PR2_RunAll();
```

The Maple runner writes CSV reports under `reports/`:

- `reports/pr2_maple_summary.md`
- `reports/pr2_maple_results.csv`
- `reports/pr2_maple_traceability.csv`
- `reports/pr2_maple_failures.md`

It also refreshes PR-I-style audit artifacts in this folder:

- `equation_map.md`
- `equation_audit.md`
- `harness_validation.md`
- `equation_derivations.md`
- `proof_report.md`
- `qcd_threshold_recompute.md`
- `source_equation_coverage.md`
- `source_equation_inventory.csv`
- `coverage_quality_report.md`
- `direct_proof_backlog.csv`

Their roles mirror the PR-I harness:

- `equation_map.md`: maps paper sections and source checks to Maple assertions.
- `equation_audit.md`: run summary, coverage scope, and boundary interpretation.
- `harness_validation.md`: negative controls proving the harness rejects known-bad equations.
- `equation_derivations.md`: derivation routes for central equations.
- `proof_report.md`: residuals/results for every passing assertion.
- `qcd_threshold_recompute.md`: focused QCD threshold and running recomputation ledger.
- `source_equation_coverage.md`: every top-level display equation block in the TeX source, with status.
- `source_equation_inventory.csv`: machine-readable inventory behind the coverage report.
- `coverage_quality_report.md`: separates full accounting from direct Maple proof density.
- `direct_proof_backlog.csv`: display rows to convert into more explicit PR1-style assertions or boundary notes.

## Local Reference Reports

Maple was not available on the Codex shell PATH in this environment. To still
produce an auditable report now, `scripts/reference_runner.py` mirrors the Maple
core numeric checks with the bundled Python runtime and writes:

- `reports/pr2_reference_summary.md`
- `reports/pr2_reference_results.csv`
- `reports/pr2_reference_traceability.csv`
- `reports/pr2_known_issues.md`

These reference reports are not a substitute for running Maple. The Maple run is
the canonical release artifact because it also generates proof, source coverage,
derivation, and self-validation reports.

## Coverage

The harness covers:

- SU(2) generator algebra, Casimir normalization, ladder actions, and charge locking.
- Electroweak neutral mass matrix, photon masslessness, rho identity, Fermi limit,
  scalar coupling ledger, and neutral-current couplings.
- PR-I inherited boundary constants, weak mixing, weak scale, Fermi constant,
  and diagnostic W/Z masses.
- One-generation and three-generation anomaly cancellation.
- Generation-sheet hierarchy, sector-specific overlap spectra, and hypercharge
  neutrality.
- Charged-lepton Koide sheet candidate and mass residuals.
- Strong-coupling candidate, three-loop QCD Lambda matching, heavy thresholds,
  running diagnostics, light-quark hierarchy, and six-quark ordering.
- CKM and PMNS generated matrices, unitarity residuals, and Jarlskog invariants.
- Normal-ordering neutrino spectrum, beta and neutrinoless double-beta effective
  masses, Majorana phase boundary, and flavor-basis Majorana matrix symmetry.
- Source-text coverage against `source/Oshetski_Projection_Relativity_II_Main.tex`.

## Boundary Labels

The Maple audit separates hard machine-check failures from honest scope labels:

- `PASS`: the expression, identity, or numeric check passed.
- `ASSUMPTION`: the algebra follows under stated physical assumptions.
- `DATA`: the statement needs external diagnostic data or future precision layers.
- `MANUSCRIPT`: the checker found a paper-cleanup issue.
- `NOTE`: structural definition, deferred precision scope, or interpretation boundary.

The current harness intentionally records known manuscript cleanup items for the
Koide phase display, rho closure display, and nested `m_{\beta\beta}` boxes.

## Full Equation Coverage

The source coverage script inventories every top-level display math block in
`source/Oshetski_Projection_Relativity_II_Main.tex`. A display is considered covered when it has one of:

- `PASS`: directly or section-chain covered by Maple checks.
- `NOTE`: contextual, repeated, definitional, or interpretive display.
- `DATA`: diagnostic reference, status table, or deferred precision layer.
- `MANUSCRIPT`: paper-cleanup item that should be fixed in the TeX.

A healthy full audit has:

```text
Unmapped display blocks: 0
```

This does not mean every display block is a separate direct theorem. The quality
report separates direct Maple proofs from section-chain coverage and explicit
boundary classifications.

The Maple harness itself also reads the generated file
`src/pr2_source_equation_audit.mpl`, which adds one Maple assertion per display
block to confirm that every inventoried LaTeX display is present in the source
fixture. After regenerating and running the full audit, the Maple check count
should be substantially larger than the original 167 core mathematical checks.
With the current paper fixture, the expected rerun count is 616 Maple checks:
167 core/source-anchor checks plus 449 generated LaTeX-source assertions.

During the Maple run, the harness prints PR-I-style section headers and PASS
lines. The core calculation checks recompute the main numerical outputs from
their formulas. The generated LaTeX-source assertions verify every displayed
equation block exists and is classified; they are source coverage checks, not
independent recalculations of repeated definitions or summary restatements.
