$ErrorActionPreference = "Stop"

$harnessRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $harnessRoot

$candidates = @()

if ($env:MAPLE_BIN) {
    $candidates += (Join-Path $env:MAPLE_BIN "cmaple.exe")
    $candidates += (Join-Path $env:MAPLE_BIN "maple.exe")
}

$pathCmaple = Get-Command cmaple -ErrorAction SilentlyContinue
if ($pathCmaple) {
    $candidates += $pathCmaple.Source
}

$pathMaple = Get-Command maple -ErrorAction SilentlyContinue
if ($pathMaple) {
    $candidates += $pathMaple.Source
}

$programRoots = @(
    "${env:ProgramFiles}",
    "${env:ProgramFiles(x86)}"
) | Where-Object { $_ -and (Test-Path $_) }

foreach ($root in $programRoots) {
    $candidates += Get-ChildItem -Path $root -Directory -Filter "Maple*" -ErrorAction SilentlyContinue |
        ForEach-Object {
            @(
                (Join-Path $_.FullName "bin.X86_64_WINDOWS\cmaple.exe"),
                (Join-Path $_.FullName "bin.X86_64_WINDOWS\maple.exe"),
                (Join-Path $_.FullName "bin\cmaple.exe"),
                (Join-Path $_.FullName "bin\maple.exe")
            )
        }
}

$mapleExe = $candidates |
    Where-Object { $_ -and (Test-Path $_) } |
    Select-Object -First 1

if (-not $mapleExe) {
    Write-Host "Could not find Maple on PATH or in common Program Files locations."
    Write-Host "Set MAPLE_BIN to your Maple bin folder, then run this script again."
    Write-Host "Example:"
    Write-Host '  $env:MAPLE_BIN="C:\Program Files\Maple 2025\bin.X86_64_WINDOWS"'
    exit 1
}

Write-Host "Using Maple executable: $mapleExe"
& $mapleExe "run_appendix_verification.mpl"

if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

Write-Host ""
Write-Host "Maple reports:"
Write-Host "  $harnessRoot\reports\pr2_maple_summary.md"
Write-Host "  $harnessRoot\reports\pr2_maple_results.csv"
Write-Host "  $harnessRoot\reports\pr2_maple_traceability.csv"
Write-Host "  $harnessRoot\reports\pr2_maple_failures.md"
Write-Host "  $harnessRoot\equation_map.md"
Write-Host "  $harnessRoot\equation_audit.md"
Write-Host "  $harnessRoot\harness_validation.md"
Write-Host "  $harnessRoot\equation_derivations.md"
Write-Host "  $harnessRoot\proof_report.md"
Write-Host "  $harnessRoot\qcd_threshold_recompute.md"
