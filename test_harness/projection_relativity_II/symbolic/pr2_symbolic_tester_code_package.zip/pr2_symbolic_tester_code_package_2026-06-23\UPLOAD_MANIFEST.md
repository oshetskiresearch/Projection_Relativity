# PR-II Symbolic Tester Code Package

Package date: 2026-06-23

This folder is the uploadable code package for the Projection Relativity II Maple symbolic tester.

It contains the runnable tester code, source-fetch workflow, Maple harness, and Python coverage generators. It does not include the full generated result set; run outputs are intentionally ignored by `.gitignore` and can be generated fresh after upload.

## What To Upload

Upload the contents of this folder to the GitHub repository location where you want the symbolic tester to live.

Recommended repository path:

```text
symbolic_tester/
```

## Main Entrypoints

- `run_full_audit_windows.ps1` - one-command Windows runner
- `fetch_github_source.ps1` - downloads the latest GitHub manuscript source
- `run_maple_windows.ps1` - finds and runs Maple
- `run_appendix_verification.mpl` - Maple runner file
- `ProjectionRelativityIIAppendixVerify.mpl` - Maple harness entrypoint

## Core Code

- `src/pr2_harness.mpl` - Maple harness framework
- `src/pr2_tests.mpl` - symbolic and numeric PR-II checks
- `src/pr2_source_equation_audit.mpl` - generated Maple source-coverage assertions
- `scripts/equation_coverage.py` - LaTeX display-block inventory generator
- `scripts/generate_maple_source_audit.py` - source audit Maple generator
- `scripts/coverage_quality.py` - coverage quality report generator
- `scripts/reference_runner.py` - Python reference runner

## How To Run

From this folder on Windows:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run_full_audit_windows.ps1
```

The full audit flow is:

1. Fetch the latest manuscript from GitHub.
2. Regenerate source equation coverage.
3. Regenerate the Maple source-audit file.
4. Run the Maple symbolic tester.
5. Refresh the coverage quality report.

## Generated Files

After a run, the harness writes generated outputs such as:

- `reports/pr2_maple_summary.md`
- `reports/pr2_maple_results.csv`
- `reports/pr2_maple_traceability.csv`
- `source/Oshetski_Projection_Relativity_II_Main.tex`
- `source/github_source_manifest.json`
- `source_equation_coverage.md`
- `source_equation_inventory.csv`
- `coverage_quality_report.md`
- `proof_report.md`
- `direct_proof_backlog.csv`

These are generated artifacts. They are excluded from normal Git tracking by `.gitignore` in this code package.

## Latest Verified Result

The latest run performed before this package was created used the GitHub manuscript fetched on 2026-06-23 and reported:

```text
Maple tests: 621
Passed: 621
Failed: 0
Display blocks inventoried: 446
Unmapped display blocks: 0
```

For the result artifacts from that run, use the separate results package:

```text
outputs/pr2_symbolic_tester_rerun_2026-06-23/
```
