# Runner for the Projection Relativity II symbolic Maple harness.
# From Maple, run:
#   read "run_appendix_verification.mpl";

read "ProjectionRelativityIIAppendixVerify.mpl":
PR2_RunAll();

