# Reports Folder

Maple writes run reports here.

Typical generated files include:

- `pr2_maple_summary.md`
- `pr2_maple_results.csv`
- `pr2_maple_traceability.csv`
- `pr2_maple_failures.md`

Generated reports are intentionally ignored by `.gitignore`.
