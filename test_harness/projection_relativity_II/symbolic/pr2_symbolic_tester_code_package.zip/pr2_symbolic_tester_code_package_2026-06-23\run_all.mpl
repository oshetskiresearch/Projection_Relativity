restart:
Digits := 60:

read "src/pr2_harness.mpl":
read "src/pr2_tests.mpl":
read "src/pr2_source_equation_audit.mpl":

PR2_RunAll():

printf("PR-II Maple harness complete: %d machine checks, %d failed.\\n",
       result_count, CountFailures()):
