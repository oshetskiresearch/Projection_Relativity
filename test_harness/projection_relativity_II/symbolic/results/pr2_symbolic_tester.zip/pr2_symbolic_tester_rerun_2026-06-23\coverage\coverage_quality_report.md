# PR-II Coverage Quality Report

This report separates full source accounting from direct Maple proof density.

## Current Harness Size

- PR-II Maple source lines: 1735
- PR-II Maple procedures: 46
- Last recorded PR-II Maple checks: 621
- Recorded non-LaTeX/core checks: 167
- Generated LaTeX-source assertions included in current Maple run: 454
- Current expected Maple checks: 621
- Includes generated Maple source audit with one assertion per display block.

For comparison, the PR-I symbolic harness inspected during development has approximately:

- PR-I main Maple source lines: 1986
- PR-I Maple procedures: 64

## Display-Block Coverage

- Display blocks inventoried: 446
- Unmapped display blocks: 0
- Direct numeric/symbolic display matches: 53
- Section-chain PASS display blocks: 218
- Boundary/context/data/manuscript display blocks: 175

## Status Counts

| status | count |
| --- | --- |
| DATA | 62 |
| MANUSCRIPT | 2 |
| NOTE | 111 |
| PASS | 271 |

## Coverage Mode Counts

| mode | count |
| --- | --- |
| boundary | 62 |
| context | 11 |
| direct-numeric | 11 |
| direct-symbolic | 42 |
| note-boundary | 100 |
| paper-cleanup | 2 |
| section-chain | 218 |

## Interpretation

The PR-II harness now has complete source accounting, but it is not yet PR-I-parity in direct proof density.
The next hardening pass should convert high-value `section-chain` and `note-boundary` rows into explicit Maple assertions or explicit PR1-style boundary notes with derivation text.

Priority targets for direct-proof expansion:

1. Electroweak lift/operator definitions before the main locking section.
2. Residual charge matrix displays in the residual electromagnetic boundary section.
3. Group-valued phase and Peter-Weyl representation displays.
4. Scalar ledger definitions and PR-III-deferred equations as explicit `NOTE` rows in Maple, not only in the coverage CSV.
5. Audit-map/status tables as generated report checks.

The full backlog is written to `direct_proof_backlog.csv`.
