# PR-II Colab Harness Run Summary

Status: **PASS**

- tests_total: `146`
- tests_passed: `146`
- tests_failed: `0`
- output_directory: `/content/pr2_harness_output`

## Input discipline

Allowed generation inputs and diagnostic references are stored separately. Target observables are not used as generation inputs.

Forbidden-generation-input intersection:

```text
[]
```

## Key generated outputs

```text
sin^2(theta_W)^PR = 0.231355763298189
Lambda_EW^PR      = 173.670598344728 GeV
v_EW^PR           = 246.219595890225 GeV
G_F^PR            = 1.166379220175995e-05 GeV^-2
alpha_3^PR        = 0.117861507469150
me,mmu,mtau       = 0.510984463, 105.656418843, 1776.934589789 MeV
mu,md,ms          = 2.146462595, 4.761039493, 94.028510538 MeV
m_c,m_b,m_t       = 1.274964814257, 4.166450482675, 172.813973266662 GeV
Delta m21^2       = 7.443001213712e-05 eV^2
Delta m31^2       = 2.510666720581e-03 eV^2
m_betabeta        = 1.507694476835e-03 eV
```

## Important caveat

This harness verifies the PR-II tree-level electroweak/flavor candidate chain and negative controls. It does not claim scalar-mass closure or loop-level electroweak/QCD precision completion. Those are PR-III precision-layer targets.
